package com.hardsoft.sistema.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hardsoft.sistema.dtos.AdminRequestDTO;
import com.hardsoft.sistema.dtos.AdminResponseDTO;
import com.hardsoft.sistema.exceptions.ResourceNotFoundException;
import com.hardsoft.sistema.repositories.AdminRepository;
import com.hardsoft.sistema.repositories.ProcedureRepository;

/**
 * Administradores.
 * Leitura: view v_Admin. Gravação: procedures sp_CadAdmin, sp_AtualizarAdmin e sp_ExcluirAdmin.
 */
@Service
public class AdminService {

    @Autowired
    private AdminRepository repository;

    @Autowired
    private ProcedureRepository procedures;

    @Transactional(readOnly = true)
    public List<AdminResponseDTO> listarTodos() {
        return repository.listarView().stream().map(AdminResponseDTO::fromView).toList();
    }

    @Transactional(readOnly = true)
    public AdminResponseDTO buscarPorId(Long id) {
        return AdminResponseDTO.fromView(
            repository.buscarView(id)
                .orElseThrow(() -> new ResourceNotFoundException("Admin", id))
        );
    }

    // Gravações: a própria procedure controla a transação (por isso não há @Transactional)

    public AdminResponseDTO salvar(AdminRequestDTO dto) {
        Long id = procedures.executarRetornandoId("sp_CadAdmin",
            "nome", dto.getNome(),
            "email", dto.getEmail(),
            "senha", dto.getSenha(),
            "cargo", dto.getCargo(),
            "telefone", dto.getTelefone(),
            "endereco", dto.getEndereco());
        return buscarPorId(id);
    }

    public AdminResponseDTO atualizar(Long id, AdminRequestDTO dto) {
        procedures.executar("sp_AtualizarAdmin",
            "idAdmin", id,
            "nome", dto.getNome(),
            "email", dto.getEmail(),
            "senha", dto.getSenha(),
            "cargo", dto.getCargo(),
            "telefone", dto.getTelefone(),
            "endereco", dto.getEndereco());
        return buscarPorId(id);
    }

    /** Regra (bloqueia se houver OS finalizada) e cascata ficam na procedure sp_ExcluirAdmin. */
    public void deletar(Long id) {
        procedures.executar("sp_ExcluirAdmin", "idAdmin", id);
    }
}
