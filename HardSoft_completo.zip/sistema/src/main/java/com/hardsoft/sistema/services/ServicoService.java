package com.hardsoft.sistema.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hardsoft.sistema.dtos.ServicoRequestDTO;
import com.hardsoft.sistema.dtos.ServicoResponseDTO;
import com.hardsoft.sistema.exceptions.ResourceNotFoundException;
import com.hardsoft.sistema.repositories.OrdemServicoRepository;
import com.hardsoft.sistema.repositories.ProcedureRepository;
import com.hardsoft.sistema.repositories.ServicoRepository;

/**
 * Serviços executados dentro de uma OS.
 * Leitura: view v_ServicoExecutado.
 * Gravação: procedures sp_AddServicoOS, sp_AtualizarServico e sp_ExcluirServico.
 * O valor total da OS é recalculado pelo trigger tg_CalcTotalOS_Servico.
 */
@Service
public class ServicoService {

    @Autowired
    private ServicoRepository repository;

    @Autowired
    private OrdemServicoRepository ordemServicoRepository;

    @Autowired
    private ProcedureRepository procedures;

    @Transactional(readOnly = true)
    public List<ServicoResponseDTO> listarPorOrdemServico(Long idOrdemServico) {
        if (ordemServicoRepository.contarView(idOrdemServico) == 0) {
            throw new ResourceNotFoundException("OrdemServico", idOrdemServico);
        }
        return repository.listarViewPorOS(idOrdemServico).stream()
                .map(ServicoResponseDTO::fromView).toList();
    }

    @Transactional(readOnly = true)
    public ServicoResponseDTO buscarPorId(Long id) {
        return ServicoResponseDTO.fromView(
            repository.buscarView(id)
                .orElseThrow(() -> new ResourceNotFoundException("Servico", id))
        );
    }

    // Gravações: a própria procedure controla a transação (por isso não há @Transactional)

    public ServicoResponseDTO salvar(ServicoRequestDTO dto) {
        Long id = procedures.executarRetornandoId("sp_AddServicoOS",
            "idOS", dto.getIdOrdemServico(),
            "idTipoServico", dto.getIdTipoServico(),
            "descricaoServico", dto.getDescricaoServico(),
            "precoMaoDeObra", dto.getPrecoMaoDeObra());
        return buscarPorId(id);
    }

    public ServicoResponseDTO atualizar(Long id, ServicoRequestDTO dto) {
        procedures.executar("sp_AtualizarServico",
            "idServico", id,
            "idTipoServico", dto.getIdTipoServico(),
            "descricaoServico", dto.getDescricaoServico(),
            "precoMaoDeObra", dto.getPrecoMaoDeObra());
        return buscarPorId(id);
    }

    /** A procedure remove o serviço e as peças dele; o trigger tg_DevolveEstoque devolve as peças ao estoque. */
    public void deletar(Long id) {
        procedures.executar("sp_ExcluirServico", "idServico", id);
    }
}
