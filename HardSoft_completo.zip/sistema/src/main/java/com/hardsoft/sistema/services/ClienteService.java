package com.hardsoft.sistema.services;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hardsoft.sistema.dtos.ClienteEmailDTO;
import com.hardsoft.sistema.dtos.ClienteRequestDTO;
import com.hardsoft.sistema.dtos.ClienteResponseDTO;
import com.hardsoft.sistema.dtos.ClienteTelefoneDTO;
import com.hardsoft.sistema.exceptions.ResourceNotFoundException;
import com.hardsoft.sistema.repositories.ClienteRepository;
import com.hardsoft.sistema.repositories.ProcedureRepository;
import com.hardsoft.sistema.views.ContatoView;

/**
 * Clientes.
 * Leitura: views v_Cliente e v_ClienteContatos.
 * Gravação: procedures sp_CadCliente, sp_AtualizarCliente, sp_CadEmailCliente,
 * sp_CadTelefoneCliente, sp_ExcluirCliente (soft delete) e sp_ReativarCliente.
 * As regras (CPF/CNPJ único, um único contato principal, bloqueio de exclusão
 * com histórico) ficam no banco (procedures e triggers).
 */
@Service
public class ClienteService {

    @Autowired
    private ClienteRepository repository;

    @Autowired
    private ProcedureRepository procedures;

    @Transactional(readOnly = true)
    public List<ClienteResponseDTO> listarTodos() {
        // Retorna apenas clientes ATIVOS (os inativados por soft delete ficam ocultos)
        return listarPorStatus("ATIVO");
    }

    @Transactional(readOnly = true)
    public ClienteResponseDTO buscarPorId(Long id) {
        return ClienteResponseDTO.fromView(
            repository.buscarView(id).orElseThrow(() -> new ResourceNotFoundException("Cliente", id)),
            repository.listarContatos(id)
        );
    }

    // Gravações: cada procedure controla a própria transação (por isso não há @Transactional)

    public ClienteResponseDTO salvar(ClienteRequestDTO dto) {
        Long id = procedures.executarRetornandoId("sp_CadCliente",
            "nome", dto.getNome(),
            "cpfCnpj", dto.getCpfCnpj(),
            "rg", dto.getRg(),
            "endereco", dto.getEndereco());
        cadastrarContatos(id, dto);
        return buscarPorId(id);
    }

    public ClienteResponseDTO atualizar(Long id, ClienteRequestDTO dto) {
        // a procedure altera os dados e exclui os contatos antigos; em seguida a lista nova é cadastrada
        procedures.executar("sp_AtualizarCliente",
            "idCliente", id,
            "nome", dto.getNome(),
            "cpfCnpj", dto.getCpfCnpj(),
            "rg", dto.getRg(),
            "endereco", dto.getEndereco());
        cadastrarContatos(id, dto);
        return buscarPorId(id);
    }

    /** SOFT DELETE: a procedure marca o cliente como INATIVO (o registro continua no banco). */
    public void deletar(Long id) {
        procedures.executar("sp_ExcluirCliente", "idCliente", id);
    }

    /** Reativa um cliente que foi inativado (soft delete). */
    public ClienteResponseDTO reativar(Long id) {
        procedures.executar("sp_ReativarCliente", "idCliente", id);
        return buscarPorId(id);
    }

    /** Lista os clientes INATIVOS (para a tela de reativação). */
    @Transactional(readOnly = true)
    public List<ClienteResponseDTO> listarInativos() {
        return listarPorStatus("INATIVO");
    }

    // ------------------------------------------------------------------

    private List<ClienteResponseDTO> listarPorStatus(String status) {
        Map<Long, List<ContatoView>> contatos = repository.listarContatosPorStatus(status).stream()
            .collect(Collectors.groupingBy(ContatoView::getIdCliente));
        return repository.listarViewPorStatus(status).stream()
            .map(c -> ClienteResponseDTO.fromView(c, contatos.getOrDefault(c.getId(), List.of())))
            .toList();
    }

    /** Cadastra cada e-mail e cada telefone (os triggers garantem um único principal de cada). */
    private void cadastrarContatos(Long idCliente, ClienteRequestDTO dto) {
        for (ClienteEmailDTO e : dto.getEmails()) {
            procedures.executar("sp_CadEmailCliente",
                "idCliente", idCliente,
                "email", e.getEmail(),
                "principal", Boolean.TRUE.equals(e.getPrincipal()));
        }
        for (ClienteTelefoneDTO t : dto.getTelefones()) {
            procedures.executar("sp_CadTelefoneCliente",
                "idCliente", idCliente,
                "telefone", t.getTelefone(),
                "tipo", t.getTipo().name(),
                "principal", Boolean.TRUE.equals(t.getPrincipal()));
        }
    }
}
