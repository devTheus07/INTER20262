package com.hardsoft.sistema.views;

import java.time.LocalDate;

/** Linha da view v_Cliente. */
public interface ClienteView {
    Long getId();
    String getNome();
    String getCpfCnpj();
    String getRg();
    String getEndereco();
    LocalDate getDataCadastro();
    String getEmailPrincipal();
    String getTelefonePrincipal();
}
