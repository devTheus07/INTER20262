package com.hardsoft.sistema.dtos;

import java.time.LocalDate;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.hardsoft.sistema.entities.ClienteEntity;
import com.hardsoft.sistema.entities.TipoTelefone;
import com.hardsoft.sistema.views.ClienteView;
import com.hardsoft.sistema.views.ContatoView;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClienteResponseDTO {

    private Long id;
    private String nome;
    private String cpfCnpj;
    private String rg;
    private String endereco;
    private LocalDate dataCadastro;

    private List<ClienteEmailDTO> emails;
    private List<ClienteTelefoneDTO> telefones;

    /** Email marcado como principal (atalho pra exibicao rapida). */
    private String emailPrincipal;
    /** Telefone marcado como principal (atalho pra exibicao rapida). */
    private String telefonePrincipal;

    public static ClienteResponseDTO fromEntity(ClienteEntity c) {
        List<ClienteEmailDTO> emails = c.getEmails().stream()
            .map(e -> new ClienteEmailDTO(e.getIdEmail(), e.getEmail(), e.getPrincipal()))
            .toList();

        List<ClienteTelefoneDTO> telefones = c.getTelefones().stream()
            .map(t -> new ClienteTelefoneDTO(t.getIdTelefone(), t.getTelefone(), t.getTipo(), t.getPrincipal()))
            .toList();

        String emailPrincipal = emails.stream()
            .filter(ClienteEmailDTO::getPrincipal)
            .map(ClienteEmailDTO::getEmail)
            .findFirst().orElse(null);

        String telefonePrincipal = telefones.stream()
            .filter(ClienteTelefoneDTO::getPrincipal)
            .map(ClienteTelefoneDTO::getTelefone)
            .findFirst().orElse(null);

        return new ClienteResponseDTO(
            c.getId(),
            c.getNome(),
            c.getCpfCnpj(),
            c.getRg(),
            c.getEndereco(),
            c.getDataCadastro(),
            emails,
            telefones,
            emailPrincipal,
            telefonePrincipal
        );
    }

    /**
     * Monta o DTO a partir de uma linha da view v_Cliente e dos contatos
     * (view v_ClienteContatos) desse cliente.
     */
    public static ClienteResponseDTO fromView(ClienteView v, List<ContatoView> contatos) {
        List<ClienteEmailDTO> emails = contatos.stream()
            .filter(c -> "EMAIL".equals(c.getTipoContato()))
            .map(c -> new ClienteEmailDTO(c.getIdContato(), c.getValor(), c.getPrincipal()))
            .toList();
        List<ClienteTelefoneDTO> telefones = contatos.stream()
            .filter(c -> "TELEFONE".equals(c.getTipoContato()))
            .map(c -> new ClienteTelefoneDTO(c.getIdContato(), c.getValor(),
                TipoTelefone.valueOf(c.getSubtipo()), c.getPrincipal()))
            .toList();
        return new ClienteResponseDTO(v.getId(), v.getNome(), v.getCpfCnpj(), v.getRg(), v.getEndereco(),
            v.getDataCadastro(), emails, telefones, v.getEmailPrincipal(), v.getTelefonePrincipal());
    }
}
