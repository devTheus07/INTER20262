package com.hardsoft.sistema.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hardsoft.sistema.dtos.SetupRequestDTO;
import com.hardsoft.sistema.dtos.SetupResponseDTO;
import com.hardsoft.sistema.exceptions.ResourceNotFoundException;
import com.hardsoft.sistema.repositories.ClienteRepository;
import com.hardsoft.sistema.repositories.ProcedureRepository;
import com.hardsoft.sistema.repositories.SetupRepository;

/**
 * Setups (equipamentos dos clientes).
 * Leitura: view v_Setup. Gravação: procedures sp_CadSetup, sp_AtualizarSetup e sp_ExcluirSetup.
 */
@Service
public class SetupService {

    @Autowired
    private SetupRepository repository;

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private ProcedureRepository procedures;

    @Transactional(readOnly = true)
    public List<SetupResponseDTO> listarTodos() {
        return repository.listarView().stream().map(SetupResponseDTO::fromView).toList();
    }

    @Transactional(readOnly = true)
    public List<SetupResponseDTO> listarPorCliente(Long idCliente) {
        if (clienteRepository.contarView(idCliente) == 0) {
            throw new ResourceNotFoundException("Cliente", idCliente);
        }
        return repository.listarViewPorCliente(idCliente).stream()
                .map(SetupResponseDTO::fromView).toList();
    }

    @Transactional(readOnly = true)
    public SetupResponseDTO buscarPorId(Long id) {
        return SetupResponseDTO.fromView(
            repository.buscarView(id)
                .orElseThrow(() -> new ResourceNotFoundException("Setup", id))
        );
    }

    // Gravações: a própria procedure controla a transação (por isso não há @Transactional)

    public SetupResponseDTO salvar(SetupRequestDTO dto) {
        Long id = procedures.executarRetornandoId("sp_CadSetup",
            "idCliente", dto.getIdCliente(),
            "marca", dto.getMarca(),
            "modelo", dto.getModelo(),
            "processador", dto.getProcessador(),
            "memoria", dto.getMemoria(),
            "placaDeVideo", dto.getPlacaDeVideo(),
            "armazenamento", dto.getArmazenamento());
        return buscarPorId(id);
    }

    public SetupResponseDTO atualizar(Long id, SetupRequestDTO dto) {
        procedures.executar("sp_AtualizarSetup",
            "idSetup", id,
            "idCliente", dto.getIdCliente(),
            "marca", dto.getMarca(),
            "modelo", dto.getModelo(),
            "processador", dto.getProcessador(),
            "memoria", dto.getMemoria(),
            "placaDeVideo", dto.getPlacaDeVideo(),
            "armazenamento", dto.getArmazenamento());
        return buscarPorId(id);
    }

    /** A regra (exclusão de setups não permitida) fica na procedure sp_ExcluirSetup. */
    public void deletar(Long id) {
        procedures.executar("sp_ExcluirSetup", "idSetup", id);
    }
}
