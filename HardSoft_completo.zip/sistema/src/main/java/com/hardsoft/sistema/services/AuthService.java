package com.hardsoft.sistema.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hardsoft.sistema.dtos.LoginRequestDTO;
import com.hardsoft.sistema.dtos.LoginResponseDTO;
import com.hardsoft.sistema.exceptions.BusinessException;
import com.hardsoft.sistema.repositories.ProcedureRepository;

/**
 * Autenticação simples: quem confere e-mail e senha é a procedure sp_LoginAdmin.
 * Versão acadêmica — sem token, sem Spring Security, senha em texto puro.
 */
@Service
public class AuthService {

    @Autowired
    private ProcedureRepository procedures;

    public LoginResponseDTO login(LoginRequestDTO dto) {
        List<LoginResponseDTO> admins = procedures.executarComResultado("sp_LoginAdmin",
            (rs, i) -> new LoginResponseDTO(
                rs.getLong("id"), rs.getString("nome"), rs.getString("email"), rs.getString("cargo")),
            "email", dto.getEmail(),
            "senha", dto.getSenha());

        if (admins.isEmpty()) {
            throw new BusinessException("E-mail ou senha inválidos.");
        }
        return admins.get(0);
    }
}
