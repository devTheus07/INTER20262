package com.hardsoft.sistema.views;


/** Linha da view v_Setup. */
public interface SetupView {
    Long getIdSetup();
    Long getIdCliente();
    String getNomeCliente();
    String getMarca();
    String getModelo();
    String getProcessador();
    String getMemoria();
    String getPlacaDeVideo();
    String getArmazenamento();
}
