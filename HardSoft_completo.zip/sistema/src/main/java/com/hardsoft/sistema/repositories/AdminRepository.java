package com.hardsoft.sistema.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hardsoft.sistema.entities.AdminEntity;
import com.hardsoft.sistema.views.AdminView;

@Repository
public interface AdminRepository extends JpaRepository<AdminEntity, Long> {
    Optional<AdminEntity> findByEmail(String email);
    boolean existsByEmail(String email);

    // ---------------- Consultas pela VIEW v_Admin ----------------
    String VIEW_ADMIN = "SELECT Cod_Admin AS id, Admin_Nome AS nome, Email AS email, Telefone AS telefone, "
        + "Endereco AS endereco, Cargo AS cargo, Data_Cadastro AS dataCadastro FROM v_Admin ";

    @Query(value = VIEW_ADMIN + "ORDER BY Cod_Admin", nativeQuery = true)
    List<AdminView> listarView();

    @Query(value = VIEW_ADMIN + "WHERE Cod_Admin = :id", nativeQuery = true)
    Optional<AdminView> buscarView(@Param("id") Long id);
}
