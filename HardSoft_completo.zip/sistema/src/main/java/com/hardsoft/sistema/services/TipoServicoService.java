package com.hardsoft.sistema.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hardsoft.sistema.dtos.TipoServicoRequestDTO;
import com.hardsoft.sistema.dtos.TipoServicoResponseDTO;
import com.hardsoft.sistema.exceptions.ResourceNotFoundException;
import com.hardsoft.sistema.repositories.ProcedureRepository;
import com.hardsoft.sistema.repositories.TipoServicoRepository;

/**
 * Tipos de serviço (catálogo).
 * Leitura: view v_TipoServico. Gravação: procedures sp_CadTipoServico,
 * sp_AtualizarTipoServico e sp_ExcluirTipoServico.
 */
@Service
public class TipoServicoService {

    @Autowired
    private TipoServicoRepository repository;

    @Autowired
    private ProcedureRepository procedures;

    @Transactional(readOnly = true)
    public List<TipoServicoResponseDTO> listarTodos() {
        return repository.listarView().stream().map(TipoServicoResponseDTO::fromView).toList();
    }

    @Transactional(readOnly = true)
    public TipoServicoResponseDTO buscarPorId(Long id) {
        return TipoServicoResponseDTO.fromView(
            repository.buscarView(id)
                .orElseThrow(() -> new ResourceNotFoundException("TipoServico", id))
        );
    }

    // Gravações: a própria procedure controla a transação (por isso não há @Transactional)

    public TipoServicoResponseDTO salvar(TipoServicoRequestDTO dto) {
        Long id = procedures.executarRetornandoId("sp_CadTipoServico",
            "nome", dto.getNome(),
            "descricao", dto.getDescricao(),
            "valorBase", dto.getValorBase());
        return buscarPorId(id);
    }

    public TipoServicoResponseDTO atualizar(Long id, TipoServicoRequestDTO dto) {
        procedures.executar("sp_AtualizarTipoServico",
            "idTipoServico", id,
            "nome", dto.getNome(),
            "descricao", dto.getDescricao(),
            "valorBase", dto.getValorBase());
        return buscarPorId(id);
    }

    /** A regra (exclusão de tipos de serviço não permitida) fica na procedure sp_ExcluirTipoServico. */
    public void deletar(Long id) {
        procedures.executar("sp_ExcluirTipoServico", "idTipoServico", id);
    }
}
