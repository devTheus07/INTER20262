package com.hardsoft.sistema.views;

import java.math.BigDecimal;

/** Linha da view v_ServicoExecutado. */
public interface ServicoView {
    Long getIdServico();
    Long getIdOrdemServico();
    Long getIdTipoServico();
    String getNomeTipoServico();
    String getDescricaoServico();
    BigDecimal getPrecoMaoDeObra();
}
