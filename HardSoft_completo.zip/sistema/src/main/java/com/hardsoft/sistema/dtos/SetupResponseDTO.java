package com.hardsoft.sistema.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.hardsoft.sistema.entities.SetupEntity;
import com.hardsoft.sistema.views.SetupView;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SetupResponseDTO {

    private Long idSetup;
    private Long idCliente;
    private String nomeCliente;
    private String marca;
    private String modelo;
    private String processador;
    private String memoria;
    private String placaDeVideo;
    private String armazenamento;

    public static SetupResponseDTO fromEntity(SetupEntity s) {
        return new SetupResponseDTO(
            s.getIdSetup(),
            s.getCliente() != null ? s.getCliente().getId() : null,
            s.getCliente() != null ? s.getCliente().getNome() : null,
            s.getMarca(),
            s.getModelo(),
            s.getProcessador(),
            s.getMemoria(),
            s.getPlacaDeVideo(),
            s.getArmazenamento()
        );
    }

    /** Monta o DTO a partir de uma linha da view v_Setup. */
    public static SetupResponseDTO fromView(SetupView v) {
        return new SetupResponseDTO(v.getIdSetup(), v.getIdCliente(), v.getNomeCliente(), v.getMarca(),
            v.getModelo(), v.getProcessador(), v.getMemoria(), v.getPlacaDeVideo(), v.getArmazenamento());
    }
}
