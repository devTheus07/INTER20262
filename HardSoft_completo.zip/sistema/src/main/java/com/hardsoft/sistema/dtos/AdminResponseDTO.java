package com.hardsoft.sistema.dtos;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.hardsoft.sistema.entities.AdminEntity;
import com.hardsoft.sistema.views.AdminView;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdminResponseDTO {

    private Long id;
    private String nome;
    private String email;
    private String telefone;
    private String endereco;
    private String cargo;
    private LocalDate dataCadastro;

    public static AdminResponseDTO fromEntity(AdminEntity a) {
        return new AdminResponseDTO(
            a.getId(),
            a.getNome(),
            a.getEmail(),
            a.getTelefone(),
            a.getEndereco(),
            a.getCargo(),
            a.getDataCadastro()
        );
    }

    /** Monta o DTO a partir de uma linha da view v_Admin. */
    public static AdminResponseDTO fromView(AdminView v) {
        return new AdminResponseDTO(v.getId(), v.getNome(), v.getEmail(), v.getTelefone(),
            v.getEndereco(), v.getCargo(), v.getDataCadastro());
    }
}
