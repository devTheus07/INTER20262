package com.hardsoft.sistema.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hardsoft.sistema.dtos.PecaRequestDTO;
import com.hardsoft.sistema.dtos.PecaResponseDTO;
import com.hardsoft.sistema.exceptions.ResourceNotFoundException;
import com.hardsoft.sistema.repositories.PecaRepository;
import com.hardsoft.sistema.repositories.ProcedureRepository;

/**
 * Peças (estoque).
 * Leitura: view v_PecaEstoque e function fc_PecasEstoqueMinimo.
 * Gravação: procedures sp_CadPeca, sp_AtualizarPeca e sp_ExcluirPeca.
 */
@Service
public class PecaService {

    @Autowired
    private PecaRepository repository;

    @Autowired
    private ProcedureRepository procedures;

    @Transactional(readOnly = true)
    public List<PecaResponseDTO> listarTodos() {
        return repository.listarView().stream().map(PecaResponseDTO::fromView).toList();
    }

    @Transactional(readOnly = true)
    public PecaResponseDTO buscarPorId(Long id) {
        return PecaResponseDTO.fromView(
            repository.buscarView(id)
                .orElseThrow(() -> new ResourceNotFoundException("Peca", id))
        );
    }

    @Transactional(readOnly = true)
    public List<PecaResponseDTO> buscarPorNome(String nome) {
        return repository.buscarViewPorNome(nome).stream()
                .map(PecaResponseDTO::fromView).toList();
    }

    /** Usa a function fc_PecasEstoqueMinimo. */
    @Transactional(readOnly = true)
    public List<PecaResponseDTO> estoqueBaixo(Integer limite) {
        return repository.estoqueMinimo(limite).stream()
                .map(PecaResponseDTO::fromView).toList();
    }

    // Gravações: a própria procedure controla a transação (por isso não há @Transactional)

    public PecaResponseDTO salvar(PecaRequestDTO dto) {
        Long id = procedures.executarRetornandoId("sp_CadPeca",
            "nome", dto.getNome(),
            "descricao", dto.getDescricao(),
            "marca", dto.getMarca(),
            "condicao", dto.getCondicao(),
            "precoCusto", dto.getPrecoCusto(),
            "precoVenda", dto.getPrecoVenda(),
            "qtdEstoque", dto.getQntEstoque());
        return buscarPorId(id);
    }

    public PecaResponseDTO atualizar(Long id, PecaRequestDTO dto) {
        procedures.executar("sp_AtualizarPeca",
            "idPeca", id,
            "nome", dto.getNome(),
            "descricao", dto.getDescricao(),
            "marca", dto.getMarca(),
            "condicao", dto.getCondicao(),
            "precoCusto", dto.getPrecoCusto(),
            "precoVenda", dto.getPrecoVenda(),
            "qtdEstoque", dto.getQntEstoque());
        return buscarPorId(id);
    }

    /** A regra (exclusão de peças não permitida) fica na procedure sp_ExcluirPeca. */
    public void deletar(Long id) {
        procedures.executar("sp_ExcluirPeca", "idPeca", id);
    }
}
