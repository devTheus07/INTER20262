package com.hardsoft.sistema.dtos;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.hardsoft.sistema.entities.TipoServicoEntity;
import com.hardsoft.sistema.views.TipoServicoView;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TipoServicoResponseDTO {

    private Long idTipoServico;
    private String nome;
    private String descricao;
    private BigDecimal valorBase;

    public static TipoServicoResponseDTO fromEntity(TipoServicoEntity t) {
        return new TipoServicoResponseDTO(
            t.getIdTipoServico(),
            t.getNome(),
            t.getDescricao(),
            t.getValorBase()
        );
    }

    /** Monta o DTO a partir de uma linha da view v_TipoServico. */
    public static TipoServicoResponseDTO fromView(TipoServicoView v) {
        return new TipoServicoResponseDTO(v.getIdTipoServico(), v.getNome(), v.getDescricao(), v.getValorBase());
    }
}
