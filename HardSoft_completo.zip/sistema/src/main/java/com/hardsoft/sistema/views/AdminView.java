package com.hardsoft.sistema.views;

import java.time.LocalDate;

/** Linha da view v_Admin. */
public interface AdminView {
    Long getId();
    String getNome();
    String getEmail();
    String getTelefone();
    String getEndereco();
    String getCargo();
    LocalDate getDataCadastro();
}
