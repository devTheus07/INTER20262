package com.hardsoft.sistema.repositories;

import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameterValue;
import org.springframework.stereotype.Component;

import com.hardsoft.sistema.exceptions.BusinessException;
import com.hardsoft.sistema.exceptions.ResourceNotFoundException;

/**
 * Executa as STORED PROCEDURES do banco (todas as gravações do sistema).
 * As leituras ficam nos demais repositories, por meio de views e functions.
 *
 * Cada procedure controla a própria transação; por isso os services
 * não abrem transação (@Transactional) nos métodos que gravam.
 *
 * As procedures sinalizam problemas com THROW:
 *   50001 = registro não encontrado  -> ResourceNotFoundException (HTTP 404)
 *   50002 = regra de negócio violada -> BusinessException         (HTTP 422)
 */
@Component
public class ProcedureRepository {

    public static final int ERRO_NAO_ENCONTRADO = 50001;
    public static final int ERRO_REGRA_NEGOCIO = 50002;

    private final JdbcTemplate jdbc;

    public ProcedureRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    // ------------------------------------------------------------------
    // ESCRITA: stored procedures
    // Parâmetros no formato: "nome1", valor1, "nome2", valor2, ...
    // Gera: EXEC sp_X @nome1 = ?, @nome2 = ?
    // ------------------------------------------------------------------

    /** Executa uma procedure que não devolve dados (atualizar, excluir...). */
    public void executar(String procedure, Object... pares) {
        try {
            jdbc.update(montarChamada(procedure, pares), valores(pares));
        } catch (DataAccessException e) {
            throw traduzir(e);
        }
    }

    /** Executa uma procedure que devolve linhas (ex.: sp_LoginAdmin). */
    public <T> List<T> executarComResultado(String procedure, RowMapper<T> mapper, Object... pares) {
        try {
            return jdbc.query(montarChamada(procedure, pares), mapper, valores(pares));
        } catch (DataAccessException e) {
            throw traduzir(e);
        }
    }

    /** Executa uma procedure de cadastro e devolve o id gerado (a procedure faz SELECT id). */
    public Long executarRetornandoId(String procedure, Object... pares) {
        List<Long> ids = executarComResultado(procedure, (rs, i) -> rs.getLong(1), pares);
        if (ids.isEmpty()) {
            throw new IllegalStateException("A procedure " + procedure + " não devolveu o id gerado.");
        }
        return ids.get(0);
    }

    // ------------------------------------------------------------------
    // Internos
    // ------------------------------------------------------------------

    private static String montarChamada(String procedure, Object[] pares) {
        if (pares.length % 2 != 0) {
            throw new IllegalArgumentException("Os parâmetros da procedure devem vir em pares nome/valor.");
        }
        StringBuilder sql = new StringBuilder("EXEC ").append(procedure);
        for (int i = 0; i < pares.length; i += 2) {
            sql.append(i == 0 ? " " : ", ").append('@').append(pares[i]).append(" = ?");
        }
        return sql.toString();
    }

    private static Object[] valores(Object[] pares) {
        Object[] valores = new Object[pares.length / 2];
        for (int i = 0; i < valores.length; i++) {
            valores[i] = tratarNulo(pares[i * 2 + 1]);
        }
        return valores;
    }

    /** O driver precisa saber o tipo de um parâmetro nulo. */
    private static Object tratarNulo(Object valor) {
        return valor == null ? new SqlParameterValue(Types.NVARCHAR, null) : valor;
    }

    /** Converte o erro do SQL Server (THROW 50001/50002) na exceção HTTP correspondente. */
    private RuntimeException traduzir(DataAccessException e) {
        for (Throwable t = e; t != null; t = t.getCause()) {
            if (t instanceof SQLException sql) {
                if (sql.getErrorCode() == ERRO_NAO_ENCONTRADO) {
                    return new ResourceNotFoundException(sql.getMessage());
                }
                if (sql.getErrorCode() == ERRO_REGRA_NEGOCIO) {
                    return new BusinessException(sql.getMessage());
                }
                break;
            }
        }
        return e;
    }
}
