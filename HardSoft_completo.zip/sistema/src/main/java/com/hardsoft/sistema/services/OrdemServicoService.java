package com.hardsoft.sistema.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hardsoft.sistema.dtos.OrdemServicoRequestDTO;
import com.hardsoft.sistema.dtos.OrdemServicoResponseDTO;
import com.hardsoft.sistema.exceptions.ResourceNotFoundException;
import com.hardsoft.sistema.repositories.ClienteRepository;
import com.hardsoft.sistema.repositories.OrdemServicoRepository;
import com.hardsoft.sistema.repositories.ProcedureRepository;

/**
 * Ordens de serviço.
 * Leitura: view v_OS e function fc_OSsPorCliente.
 * Gravação: procedures sp_AbrirOS, sp_AtualizarOS, sp_AlterarStatusOS e sp_ExcluirOS.
 *
 * O valor total da OS, a data de saída e a trava de status (OS finalizada não muda)
 * são mantidos pelos triggers do banco.
 */
@Service
public class OrdemServicoService {

    @Autowired
    private OrdemServicoRepository repository;

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private ProcedureRepository procedures;

    @Transactional(readOnly = true)
    public List<OrdemServicoResponseDTO> listarTodos() {
        return repository.listarView().stream().map(OrdemServicoResponseDTO::fromView).toList();
    }

    @Transactional(readOnly = true)
    public OrdemServicoResponseDTO buscarPorId(Long id) {
        return OrdemServicoResponseDTO.fromView(
            repository.buscarView(id)
                .orElseThrow(() -> new ResourceNotFoundException("OrdemServico", id))
        );
    }

    /** Histórico do cliente pela function fc_OSsPorCliente. */
    @Transactional(readOnly = true)
    public List<OrdemServicoResponseDTO> listarPorCliente(Long idCliente) {
        if (clienteRepository.contarView(idCliente) == 0) {
            throw new ResourceNotFoundException("Cliente", idCliente);
        }
        return repository.listarPorClienteFunction(idCliente).stream()
                .map(OrdemServicoResponseDTO::fromView).toList();
    }

    @Transactional(readOnly = true)
    public List<OrdemServicoResponseDTO> listarPorStatus(String status) {
        return repository.listarViewPorStatus(status).stream()
                .map(OrdemServicoResponseDTO::fromView).toList();
    }

    // Gravações: a própria procedure controla a transação (por isso não há @Transactional)

    public OrdemServicoResponseDTO salvar(OrdemServicoRequestDTO dto) {
        // Regra "o setup tem que pertencer ao cliente" fica na procedure sp_AbrirOS
        Long id = procedures.executarRetornandoId("sp_AbrirOS",
            "idCliente", dto.getIdCliente(),
            "idSetup", dto.getIdSetup(),
            "idAdmin", dto.getIdAdmin(),
            "defeito", dto.getDefeito(),
            "solucao", dto.getSolucao(),
            "status", dto.getStatus());
        return buscarPorId(id);
    }

    public OrdemServicoResponseDTO atualizar(Long id, OrdemServicoRequestDTO dto) {
        procedures.executar("sp_AtualizarOS",
            "idOS", id,
            "idCliente", dto.getIdCliente(),
            "idSetup", dto.getIdSetup(),
            "idAdmin", dto.getIdAdmin(),
            "defeito", dto.getDefeito(),
            "solucao", dto.getSolucao(),
            "status", dto.getStatus());
        return buscarPorId(id);
    }

    /** Trava de OS finalizada e data de saída: procedure sp_AlterarStatusOS + trigger tg_StatusOS. */
    public OrdemServicoResponseDTO atualizarStatus(Long id, String novoStatus) {
        procedures.executar("sp_AlterarStatusOS", "idOS", id, "novoStatus", novoStatus);
        return buscarPorId(id);
    }

    /** Regra (não exclui OS finalizada) e devolução de peças ao estoque: procedure sp_ExcluirOS. */
    public void deletar(Long id) {
        procedures.executar("sp_ExcluirOS", "idOS", id);
    }
}
