package com.hardsoft.sistema.views;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Linha da view v_OS ou da function fc_OSsPorCliente. */
public interface OrdemServicoView {
    Long getIdOrdemServico();
    LocalDateTime getDataEntrada();
    LocalDateTime getDataSaida();
    String getStatus();
    String getDefeito();
    String getSolucao();
    BigDecimal getValorTotal();
    Long getIdCliente();
    String getNomeCliente();
    Long getIdSetup();
    String getDescricaoSetup();
    Long getIdAdmin();
    String getNomeAdmin();
}
