package com.hardsoft.sistema.dtos;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.hardsoft.sistema.entities.ServicoEntity;
import com.hardsoft.sistema.views.ServicoView;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ServicoResponseDTO {

    private Long idServico;
    private Long idOrdemServico;
    private Long idTipoServico;
    private String nomeTipoServico;
    private String descricaoServico;
    private BigDecimal precoMaoDeObra;

    public static ServicoResponseDTO fromEntity(ServicoEntity s) {
        return new ServicoResponseDTO(
            s.getIdServico(),
            s.getOrdemServico() != null ? s.getOrdemServico().getIdOrdemServico() : null,
            s.getTipoServico() != null ? s.getTipoServico().getIdTipoServico() : null,
            s.getTipoServico() != null ? s.getTipoServico().getNome() : null,
            s.getDescricaoServico(),
            s.getPrecoMaoDeObra()
        );
    }

    /** Monta o DTO a partir de uma linha da view v_ServicoExecutado. */
    public static ServicoResponseDTO fromView(ServicoView v) {
        return new ServicoResponseDTO(v.getIdServico(), v.getIdOrdemServico(), v.getIdTipoServico(),
            v.getNomeTipoServico(), v.getDescricaoServico(), v.getPrecoMaoDeObra());
    }
}
