package com.hardsoft.sistema.views;

import java.math.BigDecimal;

/** Linha da view v_TipoServico. */
public interface TipoServicoView {
    Long getIdTipoServico();
    String getNome();
    String getDescricao();
    BigDecimal getValorBase();
}
