package com.hardsoft.sistema.views;

import java.math.BigDecimal;

/** Linha da view v_PecaEstoque ou da function fc_PecasEstoqueMinimo. */
public interface PecaView {
    Long getIdPeca();
    String getNome();
    String getDescricao();
    String getMarca();
    String getCondicao();
    BigDecimal getPrecoCusto();
    BigDecimal getPrecoVenda();
    Integer getQntEstoque();
}
