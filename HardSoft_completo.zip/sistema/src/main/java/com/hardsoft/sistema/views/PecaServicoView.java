package com.hardsoft.sistema.views;

import java.math.BigDecimal;

/** Linha da view v_PecaServico. */
public interface PecaServicoView {
    Long getIdPecaServico();
    Long getIdServico();
    Long getIdPeca();
    String getNomePeca();
    Integer getQntVendida();
    BigDecimal getVlrUnitarioVenda();
    BigDecimal getSubtotal();
}
