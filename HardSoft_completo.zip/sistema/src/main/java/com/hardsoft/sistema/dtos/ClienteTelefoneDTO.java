package com.hardsoft.sistema.dtos;

import com.hardsoft.sistema.entities.TipoTelefone;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClienteTelefoneDTO {

    private Long idTelefone; // null na criacao

    @NotBlank(message = "Telefone é obrigatório")
    @Size(max = 20)
    private String telefone;

    @NotNull(message = "Tipo do telefone é obrigatório (CELULAR, FIXO, COMERCIAL)")
    private TipoTelefone tipo;

    @NotNull(message = "Indique se este é o telefone principal (true/false)")
    private Boolean principal;
}
