package com.hardsoft.sistema.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hardsoft.sistema.entities.OrdemServicoEntity;
import com.hardsoft.sistema.views.OrdemServicoView;

@Repository
public interface OrdemServicoRepository extends JpaRepository<OrdemServicoEntity, Long> {

    List<OrdemServicoEntity> findByClienteId(Long clienteId);

    List<OrdemServicoEntity> findByAdminId(Long adminId);

    List<OrdemServicoEntity> findBySetupIdSetup(Long idSetup);

    List<OrdemServicoEntity> findByStatusIgnoreCase(String status);

    // Para validacoes de exclusao
    boolean existsByClienteId(Long clienteId);
    boolean existsByAdminId(Long adminId);
    boolean existsBySetupIdSetup(Long idSetup);

    // Para validar exclusao com preservacao de historico:
    // bloqueia se houver OS CONCLUIDA ou ENTREGUE
    boolean existsByClienteIdAndStatusIgnoreCaseIn(Long clienteId, List<String> statuses);
    boolean existsByAdminIdAndStatusIgnoreCaseIn(Long adminId, List<String> statuses);

    // ---------------- Consultas pela VIEW v_OS e pela FUNCTION fc_OSsPorCliente ----------------
    String COLUNAS_OS = "SELECT Cod_OS AS idOrdemServico, Data_Entrada AS dataEntrada, Data_Saida AS dataSaida, "
        + "Status_Codigo AS status, Defeito AS defeito, Solucao AS solucao, Valor_Total AS valorTotal, "
        + "Cod_Cliente AS idCliente, Cliente AS nomeCliente, Cod_Setup AS idSetup, Equipamento AS descricaoSetup, "
        + "Cod_Admin AS idAdmin, Tecnico_Responsavel AS nomeAdmin ";

    @Query(value = COLUNAS_OS + "FROM v_OS ORDER BY Cod_OS", nativeQuery = true)
    List<OrdemServicoView> listarView();

    @Query(value = COLUNAS_OS + "FROM v_OS WHERE Cod_OS = :id", nativeQuery = true)
    Optional<OrdemServicoView> buscarView(@Param("id") Long id);

    @Query(value = COLUNAS_OS + "FROM v_OS WHERE UPPER(Status_Codigo) = UPPER(:status) ORDER BY Cod_OS", nativeQuery = true)
    List<OrdemServicoView> listarViewPorStatus(@Param("status") String status);

    @Query(value = COLUNAS_OS + "FROM dbo.fc_OSsPorCliente(:idCliente) ORDER BY Cod_OS", nativeQuery = true)
    List<OrdemServicoView> listarPorClienteFunction(@Param("idCliente") Long idCliente);

    @Query(value = "SELECT COUNT(*) FROM v_OS WHERE Cod_OS = :id", nativeQuery = true)
    int contarView(@Param("id") Long id);
}
