package com.hardsoft.sistema.dtos;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.hardsoft.sistema.entities.PecaEntity;
import com.hardsoft.sistema.views.PecaView;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PecaResponseDTO {

    private Long idPeca;
    private String nome;
    private String descricao;
    private String marca;
    private String condicao;
    private BigDecimal precoCusto;
    private BigDecimal precoVenda;
    private Integer qntEstoque;

    public static PecaResponseDTO fromEntity(PecaEntity p) {
        return new PecaResponseDTO(
            p.getIdPeca(),
            p.getNome(),
            p.getDescricao(),
            p.getMarca(),
            p.getCondicao(),
            p.getPrecoCusto(),
            p.getPrecoVenda(),
            p.getQntEstoque()
        );
    }

    /** Monta o DTO a partir de uma linha da view v_PecaEstoque (ou da function fc_PecasEstoqueMinimo). */
    public static PecaResponseDTO fromView(PecaView v) {
        return new PecaResponseDTO(v.getIdPeca(), v.getNome(), v.getDescricao(), v.getMarca(),
            v.getCondicao(), v.getPrecoCusto(), v.getPrecoVenda(), v.getQntEstoque());
    }
}
