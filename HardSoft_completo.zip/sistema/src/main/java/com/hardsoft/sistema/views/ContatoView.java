package com.hardsoft.sistema.views;


/** Linha da view v_ClienteContatos (um e-mail ou um telefone do cliente). */
public interface ContatoView {
    Long getIdCliente();
    String getTipoContato();
    Long getIdContato();
    String getValor();
    String getSubtipo();
    Boolean getPrincipal();
}
