package com.hardsoft.sistema.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hardsoft.sistema.entities.ClienteEntity;
import com.hardsoft.sistema.views.ClienteView;
import com.hardsoft.sistema.views.ContatoView;

@Repository
public interface ClienteRepository extends JpaRepository<ClienteEntity, Long> {

    Optional<ClienteEntity> findByCpfCnpj(String cpfCnpj);

    boolean existsByCpfCnpj(String cpfCnpj);

    // Lista apenas clientes ATIVOS (ignora os inativados por soft delete)
    List<ClienteEntity> findByStatusClienteIgnoreCase(String statusCliente);

    // ---------------- Consultas pelas VIEWS v_Cliente e v_ClienteContatos ----------------
    String VIEW_CLIENTE = "SELECT Cod_Cliente AS id, Cliente_Nome AS nome, CPF_CNPJ AS cpfCnpj, RG AS rg, "
        + "Endereco AS endereco, Data_Cadastro AS dataCadastro, Email_Principal AS emailPrincipal, "
        + "Telefone_Principal AS telefonePrincipal FROM v_Cliente ";

    String VIEW_CONTATOS = "SELECT Cod_Cliente AS idCliente, Tipo_Contato AS tipoContato, Cod_Contato AS idContato, "
        + "Valor AS valor, Subtipo AS subtipo, Principal AS principal FROM v_ClienteContatos ";

    @Query(value = VIEW_CLIENTE + "WHERE Status_Cliente = :status ORDER BY Cod_Cliente", nativeQuery = true)
    List<ClienteView> listarViewPorStatus(@Param("status") String status);

    @Query(value = VIEW_CLIENTE + "WHERE Cod_Cliente = :id", nativeQuery = true)
    Optional<ClienteView> buscarView(@Param("id") Long id);

    @Query(value = VIEW_CONTATOS + "WHERE Cod_Cliente IN (SELECT Cod_Cliente FROM v_Cliente WHERE Status_Cliente = :status) "
        + "ORDER BY Cod_Cliente, Cod_Contato", nativeQuery = true)
    List<ContatoView> listarContatosPorStatus(@Param("status") String status);

    @Query(value = VIEW_CONTATOS + "WHERE Cod_Cliente = :id ORDER BY Cod_Contato", nativeQuery = true)
    List<ContatoView> listarContatos(@Param("id") Long id);

    @Query(value = "SELECT COUNT(*) FROM v_Cliente WHERE Cod_Cliente = :id", nativeQuery = true)
    int contarView(@Param("id") Long id);
}
