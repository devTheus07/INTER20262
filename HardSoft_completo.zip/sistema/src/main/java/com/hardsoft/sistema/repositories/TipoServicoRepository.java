package com.hardsoft.sistema.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hardsoft.sistema.entities.TipoServicoEntity;
import com.hardsoft.sistema.views.TipoServicoView;

@Repository
public interface TipoServicoRepository extends JpaRepository<TipoServicoEntity, Long> {
    Optional<TipoServicoEntity> findByNomeIgnoreCase(String nome);
    boolean existsByNomeIgnoreCase(String nome);

    // ---------------- Consultas pela VIEW v_TipoServico ----------------
    String VIEW_TIPO = "SELECT Cod_Tipo_Servico AS idTipoServico, Nome AS nome, Descricao AS descricao, "
        + "Valor_Base AS valorBase FROM v_TipoServico ";

    @Query(value = VIEW_TIPO + "ORDER BY Cod_Tipo_Servico", nativeQuery = true)
    List<TipoServicoView> listarView();

    @Query(value = VIEW_TIPO + "WHERE Cod_Tipo_Servico = :id", nativeQuery = true)
    Optional<TipoServicoView> buscarView(@Param("id") Long id);
}
