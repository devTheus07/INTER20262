package com.hardsoft.sistema.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hardsoft.sistema.entities.ServicoEntity;
import com.hardsoft.sistema.views.ServicoView;

@Repository
public interface ServicoRepository extends JpaRepository<ServicoEntity, Long> {
    List<ServicoEntity> findByOrdemServicoIdOrdemServico(Long idOrdemServico);

    boolean existsByTipoServicoIdTipoServico(Long idTipoServico);

    // ---------------- Consultas pela VIEW v_ServicoExecutado ----------------
    String VIEW_SERVICO = "SELECT Cod_Servico AS idServico, Cod_OS AS idOrdemServico, Cod_Tipo_Servico AS idTipoServico, "
        + "Tipo_Servico AS nomeTipoServico, Descricao AS descricaoServico, Mao_De_Obra AS precoMaoDeObra "
        + "FROM v_ServicoExecutado ";

    @Query(value = VIEW_SERVICO + "WHERE Cod_OS = :idOS ORDER BY Cod_Servico", nativeQuery = true)
    List<ServicoView> listarViewPorOS(@Param("idOS") Long idOS);

    @Query(value = VIEW_SERVICO + "WHERE Cod_Servico = :id", nativeQuery = true)
    Optional<ServicoView> buscarView(@Param("id") Long id);

    @Query(value = "SELECT COUNT(*) FROM v_ServicoExecutado WHERE Cod_Servico = :id", nativeQuery = true)
    int contarView(@Param("id") Long id);
}
