package com.hardsoft.sistema.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hardsoft.sistema.entities.PecaEntity;
import com.hardsoft.sistema.views.PecaView;

@Repository
public interface PecaRepository extends JpaRepository<PecaEntity, Long> {

    List<PecaEntity> findByNomeContainingIgnoreCase(String nome);

    List<PecaEntity> findByQntEstoqueLessThan(Integer quantidade);

    // ---------------- Consultas pela VIEW v_PecaEstoque e pela FUNCTION fc_PecasEstoqueMinimo ----------------
    String VIEW_PECA = "SELECT Cod_Peca AS idPeca, Peca AS nome, Descricao AS descricao, Marca AS marca, "
        + "Condicao AS condicao, Preco_Custo AS precoCusto, Preco_Venda AS precoVenda, Estoque AS qntEstoque "
        + "FROM v_PecaEstoque ";

    @Query(value = VIEW_PECA + "ORDER BY Cod_Peca", nativeQuery = true)
    List<PecaView> listarView();

    @Query(value = VIEW_PECA + "WHERE Cod_Peca = :id", nativeQuery = true)
    Optional<PecaView> buscarView(@Param("id") Long id);

    @Query(value = VIEW_PECA + "WHERE Peca LIKE CONCAT('%', :nome, '%') ORDER BY Cod_Peca", nativeQuery = true)
    List<PecaView> buscarViewPorNome(@Param("nome") String nome);

    @Query(value = "SELECT id_peca AS idPeca, nome, descricao, marca, condicao, preco_custo AS precoCusto, "
        + "preco_venda AS precoVenda, qnt_estoque AS qntEstoque "
        + "FROM dbo.fc_PecasEstoqueMinimo(:limite) ORDER BY qnt_estoque", nativeQuery = true)
    List<PecaView> estoqueMinimo(@Param("limite") Integer limite);
}
