package com.hardsoft.sistema.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hardsoft.sistema.entities.PecaServicoEntity;
import com.hardsoft.sistema.views.PecaServicoView;

@Repository
public interface PecaServicoRepository extends JpaRepository<PecaServicoEntity, Long> {
    List<PecaServicoEntity> findByServicoIdServico(Long idServico);

    boolean existsByPecaIdPeca(Long idPeca);

    // ---------------- Consultas pela VIEW v_PecaServico ----------------
    String VIEW_PECA_SERVICO = "SELECT Cod_Registro AS idPecaServico, Cod_Servico AS idServico, Cod_Peca AS idPeca, "
        + "Peca AS nomePeca, Qtd_Vendida AS qntVendida, Preco_Unit AS vlrUnitarioVenda, Subtotal AS subtotal "
        + "FROM v_PecaServico ";

    @Query(value = VIEW_PECA_SERVICO + "WHERE Cod_Servico = :idServico ORDER BY Cod_Registro", nativeQuery = true)
    List<PecaServicoView> listarViewPorServico(@Param("idServico") Long idServico);

    @Query(value = VIEW_PECA_SERVICO + "WHERE Cod_Registro = :id", nativeQuery = true)
    Optional<PecaServicoView> buscarView(@Param("id") Long id);
}
