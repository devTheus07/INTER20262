package com.hardsoft.sistema.dtos;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.hardsoft.sistema.entities.OrdemServicoEntity;
import com.hardsoft.sistema.views.OrdemServicoView;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrdemServicoResponseDTO {

    private Long idOrdemServico;
    private LocalDateTime dataEntrada;
    private LocalDateTime dataSaida;
    private String status;
    private String defeito;
    private String solucao;
    private BigDecimal valorTotal;

    private Long idCliente;
    private String nomeCliente;

    private Long idSetup;
    private String descricaoSetup;

    private Long idAdmin;
    private String nomeAdmin;

    public static OrdemServicoResponseDTO fromEntity(OrdemServicoEntity os) {
        String descSetup = null;
        if (os.getSetup() != null) {
            descSetup = (os.getSetup().getMarca() != null ? os.getSetup().getMarca() : "") +
                        " " + (os.getSetup().getModelo() != null ? os.getSetup().getModelo() : "");
            descSetup = descSetup.trim();
        }

        return new OrdemServicoResponseDTO(
            os.getIdOrdemServico(),
            os.getDataEntrada(),
            os.getDataSaida(),
            os.getStatus(),
            os.getDefeito(),
            os.getSolucao(),
            os.getValorTotal(),
            os.getCliente() != null ? os.getCliente().getId() : null,
            os.getCliente() != null ? os.getCliente().getNome() : null,
            os.getSetup() != null ? os.getSetup().getIdSetup() : null,
            descSetup,
            os.getAdmin() != null ? os.getAdmin().getId() : null,
            os.getAdmin() != null ? os.getAdmin().getNome() : null
        );
    }

    /** Monta o DTO a partir de uma linha da view v_OS (ou da function fc_OSsPorCliente). */
    public static OrdemServicoResponseDTO fromView(OrdemServicoView v) {
        return new OrdemServicoResponseDTO(v.getIdOrdemServico(), v.getDataEntrada(), v.getDataSaida(),
            v.getStatus(), v.getDefeito(), v.getSolucao(), v.getValorTotal(),
            v.getIdCliente(), v.getNomeCliente(), v.getIdSetup(), v.getDescricaoSetup(),
            v.getIdAdmin(), v.getNomeAdmin());
    }
}
