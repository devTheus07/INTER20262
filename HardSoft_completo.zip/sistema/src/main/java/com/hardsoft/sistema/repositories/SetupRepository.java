package com.hardsoft.sistema.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hardsoft.sistema.entities.SetupEntity;
import com.hardsoft.sistema.views.SetupView;

@Repository
public interface SetupRepository extends JpaRepository<SetupEntity, Long> {
    List<SetupEntity> findByClienteId(Long clienteId);

    boolean existsByClienteId(Long clienteId);

    // ---------------- Consultas pela VIEW v_Setup ----------------
    String VIEW_SETUP = "SELECT Cod_Setup AS idSetup, Cod_Cliente AS idCliente, Cliente AS nomeCliente, Marca AS marca, "
        + "Modelo AS modelo, Processador AS processador, Memoria AS memoria, Placa_De_Video AS placaDeVideo, "
        + "Armazenamento AS armazenamento FROM v_Setup ";

    @Query(value = VIEW_SETUP + "ORDER BY Cod_Setup", nativeQuery = true)
    List<SetupView> listarView();

    @Query(value = VIEW_SETUP + "WHERE Cod_Cliente = :idCliente ORDER BY Cod_Setup", nativeQuery = true)
    List<SetupView> listarViewPorCliente(@Param("idCliente") Long idCliente);

    @Query(value = VIEW_SETUP + "WHERE Cod_Setup = :id", nativeQuery = true)
    Optional<SetupView> buscarView(@Param("id") Long id);
}
