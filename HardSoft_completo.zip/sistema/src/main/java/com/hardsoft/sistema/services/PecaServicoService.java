package com.hardsoft.sistema.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hardsoft.sistema.dtos.PecaServicoRequestDTO;
import com.hardsoft.sistema.dtos.PecaServicoResponseDTO;
import com.hardsoft.sistema.exceptions.ResourceNotFoundException;
import com.hardsoft.sistema.repositories.PecaServicoRepository;
import com.hardsoft.sistema.repositories.ProcedureRepository;
import com.hardsoft.sistema.repositories.ServicoRepository;

/**
 * Peças usadas em um serviço.
 * Leitura: view v_PecaServico.
 * Gravação: procedures sp_UsarPecaServico (congela o preço e valida o estoque)
 * e sp_RemoverPecaServico. A baixa e a devolução de estoque são feitas pelos
 * triggers tg_BaixaEstoque e tg_DevolveEstoque, e o valor da OS pelo trigger tg_CalcTotalOS_Peca.
 */
@Service
public class PecaServicoService {

    @Autowired
    private PecaServicoRepository repository;

    @Autowired
    private ServicoRepository servicoRepository;

    @Autowired
    private ProcedureRepository procedures;

    @Transactional(readOnly = true)
    public List<PecaServicoResponseDTO> listarPorServico(Long idServico) {
        if (servicoRepository.contarView(idServico) == 0) {
            throw new ResourceNotFoundException("Servico", idServico);
        }
        return repository.listarViewPorServico(idServico).stream()
                .map(PecaServicoResponseDTO::fromView).toList();
    }

    @Transactional(readOnly = true)
    public PecaServicoResponseDTO buscarPorId(Long id) {
        return PecaServicoResponseDTO.fromView(
            repository.buscarView(id)
                .orElseThrow(() -> new ResourceNotFoundException("PecaServico", id))
        );
    }

    // Gravações: a própria procedure controla a transação (por isso não há @Transactional)

    public PecaServicoResponseDTO salvar(PecaServicoRequestDTO dto) {
        Long id = procedures.executarRetornandoId("sp_UsarPecaServico",
            "idServico", dto.getIdServico(),
            "idPeca", dto.getIdPeca(),
            "qtdVendida", dto.getQntVendida());
        return buscarPorId(id);
    }

    public void deletar(Long id) {
        procedures.executar("sp_RemoverPecaServico", "idPecaServico", id);
    }
}
