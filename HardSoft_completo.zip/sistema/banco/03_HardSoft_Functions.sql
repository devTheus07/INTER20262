﻿------------------------------------------------------------------
-- FACULDADE DE TECNOLOGIA DE SÃO JOSÉ DO RIO PRETO - FATEC
-- PROJETO: HARDSOFT - SISTEMA DE ORDEM DE SERVIÇO
------------------------------------------------------------------
--	SCRIPT 03: FUNCTIONS
------------------------------------------------------------------

------------------------------------------------------------------
-- ACESSAR O BANCO DE DADOS
------------------------------------------------------------------
use HardSoftDB
go

------------------------------------------------------------------
-- SCALAR-VALUE USER-DEFINED FUNCTION
------------------------------------------------------------------
-- Scalar-value: retorna apenas um valor
------------------------------------------------------------------

------------------------------------------------------------------
-- 1) Criar uma função para calcular o reajuste de um valor
-- recebido por parâmetro, sendo que a taxa de reajuste também
-- será recebida por parâmetro (taxa negativa = desconto)
------------------------------------------------------------------
create function fc_CalcReajuste(@valor decimal(10,2), @taxa decimal(10,2))
RETURNS decimal(10,2)
as
begin
	RETURN	(@valor * (1 + (@taxa / 100.0)))
end
go

------------------------------------------------------------------
-- 2) Criar uma função que receba como parâmetro o id da OS e
-- calcule o valor total da OS (mão de obra + peças usadas)
-- Usada pelos triggers que atualizam o valor total da OS
------------------------------------------------------------------
create function fc_CalcTotalOS(@idOS bigint)
RETURNS decimal(10,2)
as
begin
	-- declarar as variáveis para armazenar os valores
	declare @maoDeObra decimal(10,2), @pecas decimal(10,2)

	-- somar a mão de obra dos serviços da OS
	select	@maoDeObra = sum(preco_mao_de_obra)
	from	tb_servicos_executados
	where	id_ordem_servico = @idOS

	-- somar as peças usadas nos serviços da OS
	select	@pecas = sum(PS.qnt_vendida * PS.vlr_unitario_venda)
	from	tb_pecas_servicos PS			INNER JOIN		tb_servicos_executados S
	ON		PS.id_servico = S.id_servico
	where	S.id_ordem_servico = @idOS

	-- isnull: se a OS não tiver serviços ou peças, considera zero
	RETURN	isnull(@maoDeObra, 0) + isnull(@pecas, 0)
end
go

------------------------------------------------------------------
-- 3) Criar uma função que receba o id de uma peça e calcule
-- quantas unidades dela já foram usadas nos serviços
------------------------------------------------------------------
create function fc_QtdVendidaPeca(@idPeca bigint)
RETURNS int
as
begin
	RETURN	(
				select	isnull(sum(qnt_vendida), 0)
				from	tb_pecas_servicos
				where	id_peca = @idPeca
			)
end
go

------------------------------------------------------------------
-- Table-valued function
------------------------------------------------------------------
-- Table-valued function: retorna uma tabela
------------------------------------------------------------------

------------------------------------------------------------------
-- 4) A oficina compra peças sempre que elas atingem o estoque
-- mínimo. Criar uma função que receba o valor do mínimo e
-- retorne todas as peças que estão abaixo do mínimo
-- (usada pelo sistema na tela de estoque)
------------------------------------------------------------------
create function fc_PecasEstoqueMinimo(@minimo int)
RETURNS table
as
	return	(
				select	id_peca, nome, descricao, marca, condicao,
						preco_custo, preco_venda, qnt_estoque
				from	tb_pecas
				where	qnt_estoque < @minimo
			)
go

------------------------------------------------------------------
-- 5) Criar uma função que retorne todas as OS abertas em um
-- determinado mês e ano
-- Usar view na consulta
------------------------------------------------------------------
create function fc_OSsPorMes(@mes int, @ano int)
RETURNS table
as
	return	(
				select	Cod_OS, Data_Entrada, Cliente, Situacao_OS, Valor_Total
				from	v_OS
				where	MONTH(Data_Entrada) = @mes and YEAR(Data_Entrada) = @ano
			)
go

------------------------------------------------------------------
-- Multi-statement Table-valued function: retorna uma variável do
-- tipo tabela com colunas definidas pelo DBA
------------------------------------------------------------------

------------------------------------------------------------------
-- 6) Criar uma função que retorne todas as peças com preço de
-- venda acima de um valor recebido por parâmetro
-- Saída de dados: id, nome, preço, quantidade e valor total em
-- estoque de cada peça
------------------------------------------------------------------
create function fc_PecasPreco(@valor decimal(10,2))
RETURNS		@TB_Pecas table	(
								idPeca			bigint,
								nome			varchar(100),
								precoVenda		decimal(10,2),
								qtdEstoque		int,
								valorEstoque	decimal(12,2)
							)
as
begin
	insert into @TB_Pecas
		select	id_peca, nome, preco_venda, qnt_estoque, (qnt_estoque * preco_venda)
		from	tb_pecas
		where	preco_venda > @valor
	return
end
go

------------------------------------------------------------------
-- 7) Criar uma função que retorne todas as OS de um cliente
-- (histórico do cliente - usada pelo sistema)
-- Usar a view v_OS
------------------------------------------------------------------
create function fc_OSsPorCliente(@idCliente bigint)
RETURNS @TB_OSCliente table	(
								Cod_OS				bigint,
								Data_Entrada		datetime,
								Data_Saida			datetime,
								Status_Codigo		varchar(30),
								Defeito				varchar(max),
								Solucao				varchar(max),
								Valor_Total			decimal(10,2),
								Cod_Cliente			bigint,
								Cliente				varchar(100),
								Cod_Setup			bigint,
								Equipamento			varchar(110),
								Cod_Admin			bigint,
								Tecnico_Responsavel	varchar(100)
							)
as
begin
	insert into @TB_OSCliente
		select	Cod_OS, Data_Entrada, Data_Saida, Status_Codigo, Defeito, Solucao,
				Valor_Total, Cod_Cliente, Cliente, Cod_Setup, Equipamento,
				Cod_Admin, Tecnico_Responsavel
		from	v_OS
		where	Cod_Cliente = @idCliente
	return
end
go
