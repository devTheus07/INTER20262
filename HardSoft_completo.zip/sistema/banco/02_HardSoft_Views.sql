﻿------------------------------------------------------------------
-- FACULDADE DE TECNOLOGIA DE SÃO JOSÉ DO RIO PRETO - FATEC
-- PROJETO: HARDSOFT - SISTEMA DE ORDEM DE SERVIÇO
------------------------------------------------------------------
--	SCRIPT 02: VIEWS
--	Todas as consultas (telas de listagem) do sistema Java são
--	feitas nestas views
------------------------------------------------------------------

------------------------------------------------------------------
-- ACESSAR O BANCO DE DADOS
------------------------------------------------------------------
use HardSoftDB
go

------------------------------------------------------------------
-- 1) Criar uma view para consultar todos os administradores
-- Objetivo: juntar as tabelas Usuários e Administradores (join)
------------------------------------------------------------------
create view v_Admin
as
	select	U.id Cod_Admin, U.nome Admin_Nome, U.email Email, U.telefone Telefone,
			U.endereco Endereco, U.data_cadastro Data_Cadastro, A.cargo Cargo
	from	tb_usuarios U				INNER JOIN		tb_admins A
	ON		U.id = A.id
go

------------------------------------------------------------------
-- 2) Criar uma view para consultar todos os clientes, com o
-- e-mail e o telefone principal de cada um
-- Objetivo: juntar tabelas, usar subconsulta e case
------------------------------------------------------------------
create view v_Cliente
as
	select	C.id Cod_Cliente, U.nome Cliente_Nome, C.cpf_cnpj CPF_CNPJ, C.rg RG,
			U.endereco Endereco, U.data_cadastro Data_Cadastro,
			case len(C.cpf_cnpj)
				when 11 then 'Pessoa Física'
				when 14 then 'Pessoa Jurídica'
				else 'Indefinido'
			end Tipo_Pessoa,
			(
				select	E.email
				from	tb_cliente_emails E
				where	E.id_cliente = C.id and E.principal = 1
			) Email_Principal,
			(
				select	T.telefone
				from	tb_cliente_telefones T
				where	T.id_cliente = C.id and T.principal = 1
			) Telefone_Principal,
			C.status_cliente Status_Cliente
	from	tb_usuarios U				INNER JOIN		tb_clientes C
	ON		U.id = C.id
go

------------------------------------------------------------------
-- 3) Criar uma view para consultar todos os contatos dos clientes
-- (uma linha para cada e-mail e uma linha para cada telefone)
-- Objetivo: juntar duas consultas com union
------------------------------------------------------------------
create view v_ClienteContatos
as
	select	E.id_cliente Cod_Cliente, 'EMAIL' Tipo_Contato, E.id_email Cod_Contato,
			E.email Valor, null Subtipo, E.principal Principal
	from	tb_cliente_emails E
	union
	select	T.id_cliente, 'TELEFONE', T.id_telefone,
			T.telefone, T.tipo, T.principal
	from	tb_cliente_telefones T
go

------------------------------------------------------------------
-- 4) Criar uma view para consultar todos os setups (equipamentos)
-- com o nome do cliente dono do equipamento
------------------------------------------------------------------
create view v_Setup
as
	select	S.id_setup Cod_Setup, S.id_cliente Cod_Cliente, U.nome Cliente,
			S.marca Marca, S.modelo Modelo, S.processador Processador,
			S.memoria Memoria, S.placa_de_video Placa_De_Video,
			S.armazenamento Armazenamento,
			-- isnull troca o valor nulo por vazio para não perder o texto
			isnull(S.marca, '') + ' ' + isnull(S.modelo, '') Equipamento
	from	tb_setups S					INNER JOIN		tb_usuarios U
	ON		S.id_cliente = U.id
go

------------------------------------------------------------------
-- 5) Criar uma view para consultar todas as ordens de serviço
-- Saída de dados: dados da OS, nome do cliente, equipamento e
-- nome do técnico responsável
-- Objetivo: juntar tabela e views (join e left join)
------------------------------------------------------------------
create view v_OS
as
	select	OS.id_ordem_servico Cod_OS, OS.data_entrada Data_Entrada, OS.data_saida Data_Saida,
			OS.status Status_Codigo,
			case OS.status
				when 'ABERTA'			then 'Aberta'
				when 'EM_ANDAMENTO'		then 'Em andamento'
				when 'AGUARDANDO_PECA'	then 'Aguardando peça'
				when 'CONCLUIDA'		then 'Concluída'
				when 'ENTREGUE'			then 'Entregue'
				else 'Cancelada'
			end Situacao_OS,
			OS.defeito Defeito, OS.solucao Solucao, OS.valor_total Valor_Total,
			OS.id_cliente Cod_Cliente, vC.Cliente_Nome Cliente,
			OS.id_setup Cod_Setup, vS.Equipamento,
			OS.id_admin Cod_Admin, vA.Admin_Nome Tecnico_Responsavel
	from	tb_ordens_servico OS			INNER JOIN		v_Cliente vC
	ON		OS.id_cliente = vC.Cod_Cliente	LEFT JOIN		v_Setup vS
	ON		OS.id_setup = vS.Cod_Setup		LEFT JOIN		v_Admin vA
	ON		OS.id_admin = vA.Cod_Admin
go

------------------------------------------------------------------
-- 6) Criar uma view para consultar todas as peças do estoque
-- com o lucro unitário e a situação do estoque
------------------------------------------------------------------
create view v_PecaEstoque
as
	select	P.id_peca Cod_Peca, P.nome Peca, P.descricao Descricao, P.marca Marca,
			P.condicao Condicao, P.preco_custo Preco_Custo, P.preco_venda Preco_Venda,
			(P.preco_venda - P.preco_custo) Lucro_Unitario,
			P.qnt_estoque Estoque,
			case
				when P.qnt_estoque = 0	then 'Sem estoque'
				when P.qnt_estoque < 5	then 'Crítico'
				when P.qnt_estoque < 10	then 'Baixo'
				else 'Normal'
			end Situacao_Estoque
	from	tb_pecas P
go

------------------------------------------------------------------
-- 7) Criar uma view para consultar o catálogo de tipos de serviço
------------------------------------------------------------------
create view v_TipoServico
as
	select	T.id_tipo_servico Cod_Tipo_Servico, T.nome Nome,
			T.descricao Descricao, T.valor_base Valor_Base
	from	tb_tipos_servico T
go

------------------------------------------------------------------
-- 8) Criar uma view para consultar os serviços executados em
-- cada OS
-- Objetivo: juntar tabelas e view (view v_OS)
------------------------------------------------------------------
create view v_ServicoExecutado
as
	select	S.id_servico Cod_Servico, S.id_ordem_servico Cod_OS,
			S.id_tipo_servico Cod_Tipo_Servico, T.nome Tipo_Servico,
			S.descricao_servico Descricao, S.preco_mao_de_obra Mao_De_Obra,
			vOS.Cliente, vOS.Situacao_OS
	from	tb_servicos_executados S			INNER JOIN		tb_tipos_servico T
	ON		S.id_tipo_servico = T.id_tipo_servico	INNER JOIN		v_OS vOS
	ON		S.id_ordem_servico = vOS.Cod_OS
go

------------------------------------------------------------------
-- 9) Criar uma view para consultar as peças usadas em cada
-- serviço, com o total de cada item
------------------------------------------------------------------
create view v_PecaServico
as
	select	PS.id_peca_servico Cod_Registro, S.id_ordem_servico Cod_OS,
			PS.id_servico Cod_Servico, PS.id_peca Cod_Peca, P.nome Peca,
			PS.qnt_vendida Qtd_Vendida, PS.vlr_unitario_venda Preco_Unit,
			(PS.qnt_vendida * PS.vlr_unitario_venda) Subtotal
	from	tb_pecas_servicos PS				INNER JOIN		tb_pecas P
	ON		PS.id_peca = P.id_peca				INNER JOIN		tb_servicos_executados S
	ON		PS.id_servico = S.id_servico
go

------------------------------------------------------------------
-- 10) Criar uma view para consultar o faturamento de cada
-- administrador (somente OS concluídas ou entregues)
-- Objetivo: usar view, join e group by
------------------------------------------------------------------
create view v_FaturamentoAdmin
as
	select	vA.Cod_Admin, vA.Admin_Nome, count(OS.id_ordem_servico) Qtd_OS_Finalizadas,
			sum(OS.valor_total) Faturamento
	from	v_Admin vA						INNER JOIN		tb_ordens_servico OS
	ON		vA.Cod_Admin = OS.id_admin
	where	OS.status in ('CONCLUIDA', 'ENTREGUE')
	group by vA.Cod_Admin, vA.Admin_Nome
go
