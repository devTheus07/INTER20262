﻿------------------------------------------------------------------
-- FACULDADE DE TECNOLOGIA DE SÃO JOSÉ DO RIO PRETO - FATEC
-- PROJETO: HARDSOFT - SISTEMA DE ORDEM DE SERVIÇO
------------------------------------------------------------------
--	SCRIPT 01: CRIAÇÃO DO BANCO DE DADOS E DAS TABELAS
--
--	Ordem de execução dos scripts:
--	01_Tabelas -> 02_Views -> 03_Functions -> 04_Procedures
--	-> 05_Triggers -> 06_DadosTeste
------------------------------------------------------------------

------------------------------------------------------------------
-- CRIAR O BANCO DE DADOS
------------------------------------------------------------------
create database HardSoftDB
go

------------------------------------------------------------------
-- ACESSAR O BANCO DE DADOS
------------------------------------------------------------------
use HardSoftDB
go

------------------------------------------------------------------
-- CRIAR A TABELA USUÁRIOS
-- Guarda os dados comuns de administradores e clientes
-- (o cliente não faz login, então e-mail e senha ficam nulos)
------------------------------------------------------------------
create table tb_usuarios
(
	id				bigint			not null	primary key	identity,
	nome			varchar(100)	not null,
	email			varchar(100)		null,
	senha			varchar(60)			null,
	telefone		varchar(20)			null,
	endereco		varchar(200)		null,
	data_cadastro	date			not null
)
go

------------------------------------------------------------------
-- CRIAR A TABELA ADMINISTRADORES
-- Todo administrador é um usuário
------------------------------------------------------------------
create table tb_admins
(
	id		bigint			not null	primary key,
	cargo	varchar(50)			null,
	-- chave estrangeira
	foreign key(id)		references	tb_usuarios(id)
)
go

------------------------------------------------------------------
-- CRIAR A TABELA CLIENTES
-- Todo cliente é um usuário
------------------------------------------------------------------
create table tb_clientes
(
	id				bigint			not null	primary key,
	cpf_cnpj		varchar(14)		not null	unique,
	rg				varchar(20)			null,
	-- restrições ATIVO | INATIVO
	status_cliente	varchar(10)		not null	check(status_cliente in ('ATIVO', 'INATIVO')),
	-- restrição: CPF tem 11 dígitos e CNPJ tem 14 dígitos
	check(len(cpf_cnpj) in (11, 14)),
	-- chave estrangeira
	foreign key(id)		references	tb_usuarios(id)
)
go

------------------------------------------------------------------
-- CRIAR A TABELA E-MAILS DO CLIENTE
-- Um cliente pode ter vários e-mails, mas só um é o principal
------------------------------------------------------------------
create table tb_cliente_emails
(
	id_email	bigint			not null	primary key	identity,
	email		varchar(100)	not null,
	-- 1 - principal | 0 - secundário
	principal	bit				not null,
	-- chave estrangeira
	id_cliente	bigint			not null	references	tb_clientes(id)
)
go

------------------------------------------------------------------
-- CRIAR A TABELA TELEFONES DO CLIENTE
-- Um cliente pode ter vários telefones, mas só um é o principal
------------------------------------------------------------------
create table tb_cliente_telefones
(
	id_telefone	bigint			not null	primary key	identity,
	telefone	varchar(20)		not null,
	-- restrições CELULAR | FIXO | COMERCIAL
	tipo		varchar(20)		not null	check(tipo in ('CELULAR', 'FIXO', 'COMERCIAL')),
	-- 1 - principal | 0 - secundário
	principal	bit				not null,
	-- chave estrangeira
	id_cliente	bigint			not null	references	tb_clientes(id)
)
go

------------------------------------------------------------------
-- CRIAR A TABELA SETUPS (equipamentos dos clientes)
------------------------------------------------------------------
create table tb_setups
(
	id_setup		bigint			not null	primary key	identity,
	marca			varchar(50)			null,
	modelo			varchar(50)			null,
	processador		varchar(100)		null,
	memoria			varchar(50)			null,
	placa_de_video	varchar(100)		null,
	armazenamento	varchar(100)		null,
	-- chave estrangeira
	id_cliente		bigint			not null	references	tb_clientes(id)
)
go

------------------------------------------------------------------
-- CRIAR A TABELA PEÇAS (estoque)
------------------------------------------------------------------
create table tb_pecas
(
	id_peca		bigint			not null	primary key	identity,
	nome		varchar(100)	not null,
	descricao	varchar(200)		null,
	marca		varchar(50)			null,
	condicao	varchar(20)			null,
	preco_custo	decimal(10,2)		null	check(preco_custo >= 0),
	preco_venda	decimal(10,2)	not null	check(preco_venda >= 0),
	-- o estoque nunca pode ficar negativo
	qnt_estoque	int				not null	check(qnt_estoque >= 0)
)
go

------------------------------------------------------------------
-- CRIAR A TABELA TIPOS DE SERVIÇO (catálogo de serviços)
------------------------------------------------------------------
create table tb_tipos_servico
(
	id_tipo_servico	bigint			not null	primary key	identity,
	nome			varchar(100)	not null	unique,
	descricao		varchar(255)		null,
	valor_base		decimal(10,2)	not null	check(valor_base >= 0)
)
go

------------------------------------------------------------------
-- CRIAR A TABELA ORDENS DE SERVIÇO
------------------------------------------------------------------
create table tb_ordens_servico
(
	id_ordem_servico	bigint			not null	primary key	identity,
	data_entrada		datetime		not null,
	data_saida			datetime			null,
	-- restrições ABERTA | EM_ANDAMENTO | AGUARDANDO_PECA | CONCLUIDA | ENTREGUE | CANCELADA
	status				varchar(30)		not null	check(status in ('ABERTA', 'EM_ANDAMENTO', 'AGUARDANDO_PECA',
																		'CONCLUIDA', 'ENTREGUE', 'CANCELADA')),
	defeito				varchar(max)		null,
	solucao				varchar(max)		null,
	-- calculado pelos triggers (mão de obra + peças)
	valor_total			decimal(10,2)		null,
	-- chaves estrangeiras
	id_cliente			bigint			not null	references	tb_clientes(id),
	id_setup			bigint				null	references	tb_setups(id_setup),
	id_admin			bigint				null	references	tb_admins(id)
)
go

------------------------------------------------------------------
-- CRIAR A TABELA SERVIÇOS EXECUTADOS (serviços de cada OS)
------------------------------------------------------------------
create table tb_servicos_executados
(
	id_servico			bigint			not null	primary key	identity,
	descricao_servico	varchar(500)		null,
	preco_mao_de_obra	decimal(10,2)	not null	check(preco_mao_de_obra >= 0),
	-- chaves estrangeiras
	id_ordem_servico	bigint			not null	references	tb_ordens_servico(id_ordem_servico),
	id_tipo_servico		bigint			not null	references	tb_tipos_servico(id_tipo_servico)
)
go

------------------------------------------------------------------
-- CRIAR A TABELA PEÇAS USADAS NOS SERVIÇOS
-- (vlr_unitario_venda guarda o preço da peça no dia em que foi usada)
------------------------------------------------------------------
create table tb_pecas_servicos
(
	id_peca_servico		bigint			not null	primary key	identity,
	qnt_vendida			int				not null	check(qnt_vendida > 0),
	vlr_unitario_venda	decimal(10,2)	not null	check(vlr_unitario_venda >= 0),
	-- chaves estrangeiras
	id_servico			bigint			not null	references	tb_servicos_executados(id_servico),
	id_peca				bigint			not null	references	tb_pecas(id_peca)
)
go

------------------------------------------------------------------
-- CRIAR A TABELA DE LOG DE HISTÓRICO DE PREÇOS DAS PEÇAS
-- (preenchida pelo trigger tg_LogPrecoPeca)
------------------------------------------------------------------
create table LOG_HistoricoPrecoPeca
(
	idPeca		bigint			not null	references	tb_pecas(id_peca),
	data		datetime		not null,
	precoAntigo	decimal(10,2)	not null,
	precoNovo	decimal(10,2)	not null,
	usuario		varchar(100)	not null,
	-- chave primária composta
	primary key(idPeca, data)
)
go

------------------------------------------------------------------
-- CRIAR A TABELA DE LOG DE ABERTURA DE ORDENS DE SERVIÇO
-- (preenchida pelo trigger tg_LogOSNova)
-- Não tem chave estrangeira para a OS, pois o histórico deve
-- continuar existindo mesmo se a OS for excluída
------------------------------------------------------------------
create table LOG_HistoricoOS
(
	idOS		bigint			not null,
	data		datetime		not null,
	idCliente	bigint			not null,
	nomeCliente	varchar(100)	not null,
	nomeAdmin	varchar(100)	not null,
	usuario		varchar(100)	not null,
	-- chave primária composta
	primary key(idOS, data)
)
go
