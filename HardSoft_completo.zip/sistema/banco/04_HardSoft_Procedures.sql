﻿------------------------------------------------------------------
-- FACULDADE DE TECNOLOGIA DE SÃO JOSÉ DO RIO PRETO - FATEC
-- PROJETO: HARDSOFT - SISTEMA DE ORDEM DE SERVIÇO
------------------------------------------------------------------
--	SCRIPT 04: PROCEDURES
--	Todos os cadastros, alterações e exclusões do sistema Java são
--	feitos por estas procedures.
--
--	Padrão usado em todas as procedures:
--	- set nocount on: não devolve ao sistema a mensagem
--	  "(1 row affected)", só o resultado que interessa
--	- begin try / begin tran: se tudo der certo -> commit
--	- begin catch: se der erro -> rollback (desfaz tudo)
--	- throw: avisa o sistema que deu erro, com a mensagem que
--	  será mostrada na tela
--		throw 50001 -> registro não encontrado
--		throw 50002 -> regra do negócio não foi respeitada
--	- as procedures de cadastro devolvem o id gerado (select)
------------------------------------------------------------------

------------------------------------------------------------------
-- ACESSAR O BANCO DE DADOS
------------------------------------------------------------------
use HardSoftDB
go

------------------------------------------------------------------
-- ADMINISTRADORES
------------------------------------------------------------------

------------------------------------------------------------------
-- 1) Criar uma procedure que cadastre um administrador, mas
-- lembre-se que todo administrador é um usuário
------------------------------------------------------------------
create procedure sp_CadAdmin
(
	@nome		varchar(100),
	@email		varchar(100),
	@senha		varchar(60),
	@cargo		varchar(50),
	@telefone	varchar(20),
	@endereco	varchar(200)
)
as
begin
	set nocount on
	begin try
		begin tran
			-- regra: o e-mail não pode se repetir
			if exists (select id from tb_usuarios where email = @email)
				throw 50002, 'E-mail já cadastrado.', 1;

			-- inserir os dados na tabela Usuários
			insert into tb_usuarios (nome, email, senha, telefone, endereco, data_cadastro)
			values	(@nome, @email, @senha, @telefone, @endereco, GETDATE())
			-- recuperar o id gerado pelo BD para a tabela Usuários
			declare @idAdmin bigint
			set @idAdmin = SCOPE_IDENTITY()
			-- inserir os dados na tabela Administradores
			insert into tb_admins (id, cargo)
			values	(@idAdmin, @cargo)
		-- confirmar os dados
		commit
		print 'Administrador cadastrado com sucesso'
		-- devolver o id gerado
		select @idAdmin as id
	end try
	begin catch
		-- erro: desfazer tudo e avisar o sistema
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 2) Criar uma procedure que altere os dados de um administrador
------------------------------------------------------------------
create procedure sp_AtualizarAdmin
(
	@idAdmin	bigint,
	@nome		varchar(100),
	@email		varchar(100),
	@senha		varchar(60),
	@cargo		varchar(50),
	@telefone	varchar(20),
	@endereco	varchar(200)
)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id from tb_admins where id = @idAdmin)
				throw 50001, 'Administrador não encontrado.', 1;

			-- regra: o e-mail não pode ser igual ao de outro usuário
			if exists (select id from tb_usuarios where email = @email and id <> @idAdmin)
				throw 50002, 'E-mail já cadastrado em outro administrador.', 1;

			update	tb_usuarios set nome = @nome, email = @email, senha = @senha,
					telefone = @telefone, endereco = @endereco
			where	id = @idAdmin

			update	tb_admins set cargo = @cargo
			where	id = @idAdmin
		commit
		print 'Administrador alterado com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 3) Criar uma procedure que exclua um administrador
-- Regra: não pode excluir administrador que tenha OS concluída
-- ou entregue (preserva o histórico). As OS ainda em aberto dele
-- são excluídas junto (as peças voltam para o estoque pelo trigger)
------------------------------------------------------------------
create procedure sp_ExcluirAdmin(@idAdmin bigint)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id from tb_admins where id = @idAdmin)
				throw 50001, 'Administrador não encontrado.', 1;

			if exists (select id_ordem_servico from tb_ordens_servico
						where id_admin = @idAdmin and status in ('CONCLUIDA', 'ENTREGUE'))
				throw 50002, 'Não é possível excluir este administrador: ele tem Ordens de Serviço concluídas ou entregues (histórico).', 1;

			-- excluir as peças usadas nas OS do administrador
			delete from tb_pecas_servicos
			where id_servico in	(
									select	S.id_servico
									from	tb_servicos_executados S	INNER JOIN	tb_ordens_servico OS
									ON		S.id_ordem_servico = OS.id_ordem_servico
									where	OS.id_admin = @idAdmin
								)
			-- excluir os serviços das OS do administrador
			delete from tb_servicos_executados
			where id_ordem_servico in	(
											select id_ordem_servico from tb_ordens_servico
											where id_admin = @idAdmin
										)
			-- excluir as OS do administrador
			delete from tb_ordens_servico
			where id_admin = @idAdmin

			-- excluir o administrador e o usuário
			delete from tb_admins	where id = @idAdmin
			delete from tb_usuarios	where id = @idAdmin
		commit
		print 'Administrador excluído com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 4) Criar uma procedure para fazer o login do administrador
-- Se o e-mail e a senha estiverem certos, devolve os dados dele.
-- Se estiverem errados, não devolve nada.
------------------------------------------------------------------
create procedure sp_LoginAdmin
(
	@email	varchar(100),
	@senha	varchar(60)
)
as
begin
	set nocount on
	select	U.id, U.nome, U.email, A.cargo
	from	tb_usuarios U				INNER JOIN		tb_admins A
	ON		U.id = A.id
	-- COLLATE Latin1_General_CS_AS: diferencia letras maiúsculas e minúsculas na senha
	where	U.email = @email and U.senha = @senha COLLATE Latin1_General_CS_AS
end
go

------------------------------------------------------------------
-- CLIENTES
------------------------------------------------------------------

------------------------------------------------------------------
-- 5) Criar uma procedure que cadastre um cliente, mas lembre-se
-- que todo cliente é um usuário
-- (os e-mails e telefones são cadastrados pelas procedures
-- sp_CadEmailCliente e sp_CadTelefoneCliente)
------------------------------------------------------------------
create procedure sp_CadCliente
(
	@nome		varchar(100),
	@cpfCnpj	varchar(14),
	@rg			varchar(20),
	@endereco	varchar(200)
)
as
begin
	set nocount on
	begin try
		begin tran
			-- regra: o CPF/CNPJ não pode se repetir
			if exists (select id from tb_clientes where cpf_cnpj = @cpfCnpj and status_cliente = 'INATIVO')
				throw 50002, 'Já existe um cliente inativo com este CPF/CNPJ. Use a opção de reativar em vez de cadastrar de novo.', 1;

			if exists (select id from tb_clientes where cpf_cnpj = @cpfCnpj)
				throw 50002, 'CPF/CNPJ já cadastrado.', 1;

			-- inserir os dados na tabela Usuários
			insert into tb_usuarios (nome, endereco, data_cadastro)
			values	(@nome, @endereco, GETDATE())
			-- recuperar o id gerado pelo BD para a tabela Usuários
			declare @idCliente bigint
			set @idCliente = SCOPE_IDENTITY()
			-- inserir os dados na tabela Clientes
			insert into tb_clientes (id, cpf_cnpj, rg, status_cliente)
			values	(@idCliente, @cpfCnpj, @rg, 'ATIVO')
		commit
		print 'Cliente cadastrado com sucesso'
		select @idCliente as id
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 6) Criar uma procedure para cadastrar um e-mail do cliente
-- (o trigger tg_EmailPrincipal garante um único e-mail principal)
------------------------------------------------------------------
create procedure sp_CadEmailCliente
(
	@idCliente	bigint,
	@email		varchar(100),
	@principal	bit
)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id from tb_clientes where id = @idCliente)
				throw 50001, 'Cliente não encontrado.', 1;

			insert into tb_cliente_emails (email, principal, id_cliente)
			values	(@email, @principal, @idCliente)
		commit
		print 'E-mail cadastrado com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 7) Criar uma procedure para cadastrar um telefone do cliente
-- (o trigger tg_TelefonePrincipal garante um único telefone principal)
------------------------------------------------------------------
create procedure sp_CadTelefoneCliente
(
	@idCliente	bigint,
	@telefone	varchar(20),
	@tipo		varchar(20),
	@principal	bit
)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id from tb_clientes where id = @idCliente)
				throw 50001, 'Cliente não encontrado.', 1;

			insert into tb_cliente_telefones (telefone, tipo, principal, id_cliente)
			values	(@telefone, UPPER(@tipo), @principal, @idCliente)
		commit
		print 'Telefone cadastrado com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 8) Criar uma procedure que altere os dados de um cliente
-- Os e-mails e telefones antigos são excluídos e o sistema
-- cadastra a nova lista em seguida (sp_CadEmailCliente e
-- sp_CadTelefoneCliente)
------------------------------------------------------------------
create procedure sp_AtualizarCliente
(
	@idCliente	bigint,
	@nome		varchar(100),
	@cpfCnpj	varchar(14),
	@rg			varchar(20),
	@endereco	varchar(200)
)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id from tb_clientes where id = @idCliente)
				throw 50001, 'Cliente não encontrado.', 1;

			-- regra: o CPF/CNPJ não pode ser igual ao de outro cliente
			if exists (select id from tb_clientes where cpf_cnpj = @cpfCnpj and id <> @idCliente)
				throw 50002, 'CPF/CNPJ já cadastrado em outro cliente.', 1;

			update	tb_usuarios set nome = @nome, endereco = @endereco
			where	id = @idCliente

			update	tb_clientes set cpf_cnpj = @cpfCnpj, rg = @rg
			where	id = @idCliente

			-- excluir os contatos antigos
			delete from tb_cliente_emails		where id_cliente = @idCliente
			delete from tb_cliente_telefones	where id_cliente = @idCliente
		commit
		print 'Cliente alterado com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 9) Criar uma procedure que exclua um cliente
-- A exclusão NÃO apaga o cliente: o trigger tg_ExcluiCliente
-- apenas o inativa (status_cliente = 'INATIVO')
-- Regra: não pode excluir cliente que tenha OS concluída ou
-- entregue (preserva o histórico). As OS ainda em aberto e os
-- setups do cliente são excluídos
------------------------------------------------------------------
create procedure sp_ExcluirCliente(@idCliente bigint)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id from tb_clientes where id = @idCliente)
				throw 50001, 'Cliente não encontrado.', 1;

			if exists (select id_ordem_servico from tb_ordens_servico
						where id_cliente = @idCliente and status in ('CONCLUIDA', 'ENTREGUE'))
				throw 50002, 'Não é possível inativar este cliente: ele tem Ordens de Serviço concluídas ou entregues (histórico).', 1;

			-- excluir as peças usadas nas OS do cliente (o trigger devolve ao estoque)
			delete from tb_pecas_servicos
			where id_servico in	(
									select	S.id_servico
									from	tb_servicos_executados S	INNER JOIN	tb_ordens_servico OS
									ON		S.id_ordem_servico = OS.id_ordem_servico
									where	OS.id_cliente = @idCliente
								)
			-- excluir os serviços das OS do cliente
			delete from tb_servicos_executados
			where id_ordem_servico in	(
											select id_ordem_servico from tb_ordens_servico
											where id_cliente = @idCliente
										)
			-- excluir as OS e os setups do cliente
			delete from tb_ordens_servico	where id_cliente = @idCliente
			delete from tb_setups			where id_cliente = @idCliente

			-- "excluir" o cliente: o trigger tg_ExcluiCliente troca o delete por update
			delete from tb_clientes			where id = @idCliente
		commit
		print 'Cliente inativado com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 10) Criar uma procedure que reative um cliente inativado
------------------------------------------------------------------
create procedure sp_ReativarCliente(@idCliente bigint)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id from tb_clientes where id = @idCliente)
				throw 50001, 'Cliente não encontrado.', 1;

			update	tb_clientes set status_cliente = 'ATIVO'
			where	id = @idCliente
		commit
		print 'Cliente reativado com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- SETUPS (equipamentos dos clientes)
------------------------------------------------------------------

------------------------------------------------------------------
-- 11) Criar uma procedure para cadastrar um setup de um cliente
------------------------------------------------------------------
create procedure sp_CadSetup
(
	@idCliente		bigint,
	@marca			varchar(50),
	@modelo			varchar(50),
	@processador	varchar(100),
	@memoria		varchar(50),
	@placaDeVideo	varchar(100),
	@armazenamento	varchar(100)
)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id from tb_clientes where id = @idCliente)
				throw 50001, 'Cliente não encontrado.', 1;

			insert into tb_setups (marca, modelo, processador, memoria, placa_de_video, armazenamento, id_cliente)
			values	(@marca, @modelo, @processador, @memoria, @placaDeVideo, @armazenamento, @idCliente)

			declare @idSetup bigint
			set @idSetup = SCOPE_IDENTITY()
		commit
		print 'Setup cadastrado com sucesso'
		select @idSetup as id
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 12) Criar uma procedure que altere os dados de um setup
------------------------------------------------------------------
create procedure sp_AtualizarSetup
(
	@idSetup		bigint,
	@idCliente		bigint,
	@marca			varchar(50),
	@modelo			varchar(50),
	@processador	varchar(100),
	@memoria		varchar(50),
	@placaDeVideo	varchar(100),
	@armazenamento	varchar(100)
)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id_setup from tb_setups where id_setup = @idSetup)
				throw 50001, 'Setup não encontrado.', 1;

			if not exists (select id from tb_clientes where id = @idCliente)
				throw 50001, 'Cliente não encontrado.', 1;

			update	tb_setups set id_cliente = @idCliente, marca = @marca, modelo = @modelo,
					processador = @processador, memoria = @memoria,
					placa_de_video = @placaDeVideo, armazenamento = @armazenamento
			where	id_setup = @idSetup
		commit
		print 'Setup alterado com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 13) Criar uma procedure para a exclusão de setups
-- Regra: o sistema não permite excluir setups (eles só são
-- excluídos junto com o cliente)
------------------------------------------------------------------
create procedure sp_ExcluirSetup(@idSetup bigint)
as
begin
	throw 50002, 'A exclusão de setups não é permitida. Para retirar um equipamento, exclua o cliente ou não crie mais OS com este setup.', 1;
end
go

------------------------------------------------------------------
-- PEÇAS (estoque)
------------------------------------------------------------------

------------------------------------------------------------------
-- 14) Criar uma procedure para cadastrar novas peças no estoque
------------------------------------------------------------------
create procedure sp_CadPeca
(
	@nome		varchar(100),
	@descricao	varchar(200),
	@marca		varchar(50),
	@condicao	varchar(20),
	@precoCusto	decimal(10,2),
	@precoVenda	decimal(10,2),
	@qtdEstoque	int
)
as
begin
	set nocount on
	begin try
		begin tran
			if @precoVenda < 0 or @precoCusto < 0
				throw 50002, 'O preço da peça não pode ser negativo.', 1;

			if @qtdEstoque < 0
				throw 50002, 'O estoque não pode ser negativo.', 1;

			insert into tb_pecas (nome, descricao, marca, condicao, preco_custo, preco_venda, qnt_estoque)
			values	(@nome, @descricao, @marca, @condicao, @precoCusto, @precoVenda, @qtdEstoque)

			declare @idPeca bigint
			set @idPeca = SCOPE_IDENTITY()
		commit
		print 'Peça cadastrada com sucesso'
		select @idPeca as id
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 15) Criar uma procedure que altere os dados de uma peça
-- (se o preço mudar, o trigger tg_LogPrecoPeca registra no LOG)
------------------------------------------------------------------
create procedure sp_AtualizarPeca
(
	@idPeca		bigint,
	@nome		varchar(100),
	@descricao	varchar(200),
	@marca		varchar(50),
	@condicao	varchar(20),
	@precoCusto	decimal(10,2),
	@precoVenda	decimal(10,2),
	@qtdEstoque	int
)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id_peca from tb_pecas where id_peca = @idPeca)
				throw 50001, 'Peça não encontrada.', 1;

			if @precoVenda < 0 or @precoCusto < 0
				throw 50002, 'O preço da peça não pode ser negativo.', 1;

			if @qtdEstoque < 0
				throw 50002, 'O estoque não pode ser negativo.', 1;

			update	tb_pecas set nome = @nome, descricao = @descricao, marca = @marca,
					condicao = @condicao, preco_custo = @precoCusto,
					preco_venda = @precoVenda, qnt_estoque = @qtdEstoque
			where	id_peca = @idPeca
		commit
		print 'Peça alterada com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 16) Criar uma procedure para a exclusão de peças
-- Regra: o sistema não permite excluir peças
------------------------------------------------------------------
create procedure sp_ExcluirPeca(@idPeca bigint)
as
begin
	throw 50002, 'A exclusão de peças não é permitida. Para retirar uma peça de circulação, zere o estoque.', 1;
end
go

------------------------------------------------------------------
-- TIPOS DE SERVIÇO (catálogo)
------------------------------------------------------------------

------------------------------------------------------------------
-- 17) Criar uma procedure para cadastrar um tipo de serviço
------------------------------------------------------------------
create procedure sp_CadTipoServico
(
	@nome		varchar(100),
	@descricao	varchar(255),
	@valorBase	decimal(10,2)
)
as
begin
	set nocount on
	begin try
		begin tran
			if exists (select id_tipo_servico from tb_tipos_servico where nome = @nome)
				throw 50002, 'Já existe um tipo de serviço cadastrado com esse nome.', 1;

			insert into tb_tipos_servico (nome, descricao, valor_base)
			values	(@nome, @descricao, @valorBase)

			declare @idTipoServico bigint
			set @idTipoServico = SCOPE_IDENTITY()
		commit
		print 'Tipo de serviço cadastrado com sucesso'
		select @idTipoServico as id
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 18) Criar uma procedure que altere um tipo de serviço
------------------------------------------------------------------
create procedure sp_AtualizarTipoServico
(
	@idTipoServico	bigint,
	@nome			varchar(100),
	@descricao		varchar(255),
	@valorBase		decimal(10,2)
)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id_tipo_servico from tb_tipos_servico where id_tipo_servico = @idTipoServico)
				throw 50001, 'Tipo de serviço não encontrado.', 1;

			if exists (select id_tipo_servico from tb_tipos_servico
						where nome = @nome and id_tipo_servico <> @idTipoServico)
				throw 50002, 'Já existe um tipo de serviço cadastrado com esse nome.', 1;

			update	tb_tipos_servico set nome = @nome, descricao = @descricao, valor_base = @valorBase
			where	id_tipo_servico = @idTipoServico
		commit
		print 'Tipo de serviço alterado com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 19) Criar uma procedure para a exclusão de tipos de serviço
-- Regra: o sistema não permite excluir tipos de serviço
------------------------------------------------------------------
create procedure sp_ExcluirTipoServico(@idTipoServico bigint)
as
begin
	throw 50002, 'A exclusão de tipos de serviço não é permitida. Para retirar um tipo de circulação, apenas não crie mais serviços com ele.', 1;
end
go

------------------------------------------------------------------
-- ORDENS DE SERVIÇO
------------------------------------------------------------------

------------------------------------------------------------------
-- 20) Criar uma procedure para abrir uma nova OS
-- Regra: o setup tem que pertencer ao cliente da OS
-- (o trigger tg_LogOSNova registra a abertura no LOG)
------------------------------------------------------------------
create procedure sp_AbrirOS
(
	@idCliente	bigint,
	@idSetup	bigint,
	@idAdmin	bigint,
	@defeito	varchar(max),
	@solucao	varchar(max),
	@status		varchar(30)
)
as
begin
	set nocount on
	begin try
		begin tran
			-- declarar uma variável para armazenar o dono do setup
			declare @donoSetup bigint
			select	@donoSetup = id_cliente
			from	tb_setups
			where	id_setup = @idSetup

			if not exists (select id from tb_clientes where id = @idCliente)
				throw 50001, 'Cliente não encontrado.', 1;

			if @donoSetup is null
				throw 50001, 'Setup não encontrado.', 1;

			if not exists (select id from tb_admins where id = @idAdmin)
				throw 50001, 'Administrador não encontrado.', 1;

			if @donoSetup <> @idCliente
				throw 50002, 'O setup informado não pertence ao cliente.', 1;

			-- se o status não for informado, a OS começa ABERTA
			if @status is null or @status = ''
				set @status = 'ABERTA'

			if UPPER(@status) not in ('ABERTA', 'EM_ANDAMENTO', 'AGUARDANDO_PECA', 'CONCLUIDA', 'ENTREGUE', 'CANCELADA')
				throw 50002, 'Status inválido.', 1;

			insert into tb_ordens_servico (data_entrada, status, defeito, solucao, valor_total,
											id_cliente, id_setup, id_admin)
			values	(GETDATE(), UPPER(@status), @defeito, @solucao, 0, @idCliente, @idSetup, @idAdmin)

			declare @idOS bigint
			set @idOS = SCOPE_IDENTITY()
		commit
		print 'Ordem de Serviço aberta com sucesso'
		select @idOS as id
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 21) Criar uma procedure que altere os dados de uma OS
-- (a mudança de status é controlada pelo trigger tg_StatusOS)
------------------------------------------------------------------
create procedure sp_AtualizarOS
(
	@idOS		bigint,
	@idCliente	bigint,
	@idSetup	bigint,
	@idAdmin	bigint,
	@defeito	varchar(max),
	@solucao	varchar(max),
	@status		varchar(30)
)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id_ordem_servico from tb_ordens_servico where id_ordem_servico = @idOS)
				throw 50001, 'Ordem de Serviço não encontrada.', 1;

			if not exists (select id from tb_clientes where id = @idCliente)
				throw 50001, 'Cliente não encontrado.', 1;

			if not exists (select id_setup from tb_setups where id_setup = @idSetup)
				throw 50001, 'Setup não encontrado.', 1;

			if not exists (select id from tb_admins where id = @idAdmin)
				throw 50001, 'Administrador não encontrado.', 1;

			if not exists (select id_setup from tb_setups where id_setup = @idSetup and id_cliente = @idCliente)
				throw 50002, 'O setup informado não pertence ao cliente.', 1;

			-- se o status não for informado, a OS continua com o status atual
			if @status is null or @status = ''
				select @status = status from tb_ordens_servico where id_ordem_servico = @idOS

			if UPPER(@status) not in ('ABERTA', 'EM_ANDAMENTO', 'AGUARDANDO_PECA', 'CONCLUIDA', 'ENTREGUE', 'CANCELADA')
				throw 50002, 'Status inválido.', 1;

			update	tb_ordens_servico set id_cliente = @idCliente, id_setup = @idSetup,
					id_admin = @idAdmin, defeito = @defeito, solucao = @solucao,
					status = UPPER(@status)
			where	id_ordem_servico = @idOS
		commit
		print 'Ordem de Serviço alterada com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 22) Criar uma procedure para alterar somente o status da OS
-- (o trigger tg_StatusOS bloqueia OS finalizada, preenche a data
-- de saída e, se a OS for cancelada, devolve as peças ao estoque)
------------------------------------------------------------------
create procedure sp_AlterarStatusOS
(
	@idOS		bigint,
	@novoStatus	varchar(30)
)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id_ordem_servico from tb_ordens_servico where id_ordem_servico = @idOS)
				throw 50001, 'Ordem de Serviço não encontrada.', 1;

			if @novoStatus is null or UPPER(@novoStatus) not in ('ABERTA', 'EM_ANDAMENTO', 'AGUARDANDO_PECA',
																	'CONCLUIDA', 'ENTREGUE', 'CANCELADA')
				throw 50002, 'Status inválido.', 1;

			update	tb_ordens_servico set status = UPPER(@novoStatus)
			where	id_ordem_servico = @idOS
		commit
		print 'Status da Ordem de Serviço alterado com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 23) Criar uma procedure para excluir uma OS
-- Regra: não pode excluir OS concluída ou entregue (histórico)
-- (o trigger tg_DevolveEstoque devolve as peças ao estoque)
------------------------------------------------------------------
create procedure sp_ExcluirOS(@idOS bigint)
as
begin
	set nocount on
	begin try
		begin tran
			-- declarar uma variável para armazenar o status da OS
			declare @status varchar(30)
			select	@status = status
			from	tb_ordens_servico
			where	id_ordem_servico = @idOS

			if @status is null
				throw 50001, 'Ordem de Serviço não encontrada.', 1;

			if @status in ('CONCLUIDA', 'ENTREGUE')
				throw 50002, 'Não é possível excluir uma OS concluída ou entregue. O histórico de OS finalizadas é preservado.', 1;

			-- excluir as peças, os serviços e a OS
			delete from tb_pecas_servicos
			where id_servico in	(
									select id_servico from tb_servicos_executados
									where id_ordem_servico = @idOS
								)
			delete from tb_servicos_executados	where id_ordem_servico = @idOS
			delete from tb_ordens_servico		where id_ordem_servico = @idOS
		commit
		print 'Ordem de Serviço excluída com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- SERVIÇOS EXECUTADOS E PEÇAS USADAS
-- (o valor total da OS e o estoque são atualizados pelos triggers)
------------------------------------------------------------------

------------------------------------------------------------------
-- 24) Criar uma procedure para adicionar um serviço em uma OS
------------------------------------------------------------------
create procedure sp_AddServicoOS
(
	@idOS				bigint,
	@idTipoServico		bigint,
	@descricaoServico	varchar(500),
	@precoMaoDeObra		decimal(10,2)
)
as
begin
	set nocount on
	begin try
		begin tran
			declare @status varchar(30)
			select	@status = status
			from	tb_ordens_servico
			where	id_ordem_servico = @idOS

			if @status is null
				throw 50001, 'Ordem de Serviço não encontrada.', 1;

			if not exists (select id_tipo_servico from tb_tipos_servico where id_tipo_servico = @idTipoServico)
				throw 50001, 'Tipo de serviço não encontrado.', 1;

			if @status in ('ENTREGUE', 'CANCELADA')
				throw 50002, 'OS entregue ou cancelada não aceita novos serviços.', 1;

			insert into tb_servicos_executados (descricao_servico, preco_mao_de_obra, id_ordem_servico, id_tipo_servico)
			values	(@descricaoServico, @precoMaoDeObra, @idOS, @idTipoServico)

			declare @idServico bigint
			set @idServico = SCOPE_IDENTITY()
		commit
		print 'Serviço adicionado com sucesso'
		select @idServico as id
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 25) Criar uma procedure que altere um serviço executado
------------------------------------------------------------------
create procedure sp_AtualizarServico
(
	@idServico			bigint,
	@idTipoServico		bigint,
	@descricaoServico	varchar(500),
	@precoMaoDeObra		decimal(10,2)
)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id_servico from tb_servicos_executados where id_servico = @idServico)
				throw 50001, 'Serviço não encontrado.', 1;

			if not exists (select id_tipo_servico from tb_tipos_servico where id_tipo_servico = @idTipoServico)
				throw 50001, 'Tipo de serviço não encontrado.', 1;

			update	tb_servicos_executados set id_tipo_servico = @idTipoServico,
					descricao_servico = @descricaoServico, preco_mao_de_obra = @precoMaoDeObra
			where	id_servico = @idServico
		commit
		print 'Serviço alterado com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 26) Criar uma procedure que exclua um serviço e as peças dele
-- (o trigger tg_DevolveEstoque devolve as peças ao estoque)
------------------------------------------------------------------
create procedure sp_ExcluirServico(@idServico bigint)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id_servico from tb_servicos_executados where id_servico = @idServico)
				throw 50001, 'Serviço não encontrado.', 1;

			delete from tb_pecas_servicos		where id_servico = @idServico
			delete from tb_servicos_executados	where id_servico = @idServico
		commit
		print 'Serviço excluído com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 27) Criar uma procedure para usar uma peça em um serviço
-- Objetivo: fazer um select no código da procedure para guardar
-- o preço de venda da peça no dia do uso
-- Regra: só pode usar a peça se tiver estoque suficiente
-- (o trigger tg_BaixaEstoque dá baixa no estoque)
------------------------------------------------------------------
create procedure sp_UsarPecaServico
(
	@idServico	bigint,
	@idPeca		bigint,
	@qtdVendida	int
)
as
begin
	set nocount on
	begin try
		begin tran
			-- declarar as variáveis
			declare @statusOS varchar(30), @estoque int, @precoVenda decimal(10,2)

			-- consultar o status da OS do serviço
			select	@statusOS = OS.status
			from	tb_servicos_executados S	INNER JOIN		tb_ordens_servico OS
			ON		S.id_ordem_servico = OS.id_ordem_servico
			where	S.id_servico = @idServico

			-- consultar o estoque e o preço de venda da peça
			select	@estoque = qnt_estoque, @precoVenda = preco_venda
			from	tb_pecas
			where	id_peca = @idPeca

			if @statusOS is null
				throw 50001, 'Serviço não encontrado.', 1;

			if @precoVenda is null
				throw 50001, 'Peça não encontrada.', 1;

			if @qtdVendida is null or @qtdVendida <= 0
				throw 50002, 'A quantidade da peça deve ser maior que zero.', 1;

			if @statusOS in ('ENTREGUE', 'CANCELADA')
				throw 50002, 'OS entregue ou cancelada não aceita novas peças.', 1;

			if @qtdVendida > @estoque
				throw 50002, 'Estoque insuficiente para a peça informada.', 1;

			insert into tb_pecas_servicos (qnt_vendida, vlr_unitario_venda, id_servico, id_peca)
			values	(@qtdVendida, @precoVenda, @idServico, @idPeca)

			declare @idPecaServico bigint
			set @idPecaServico = SCOPE_IDENTITY()
		commit
		print 'Peça adicionada ao serviço com sucesso'
		select @idPecaServico as id
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go

------------------------------------------------------------------
-- 28) Criar uma procedure para remover uma peça de um serviço
-- (o trigger tg_DevolveEstoque devolve a peça ao estoque)
------------------------------------------------------------------
create procedure sp_RemoverPecaServico(@idPecaServico bigint)
as
begin
	set nocount on
	begin try
		begin tran
			if not exists (select id_peca_servico from tb_pecas_servicos where id_peca_servico = @idPecaServico)
				throw 50001, 'Peça do serviço não encontrada.', 1;

			delete from tb_pecas_servicos
			where id_peca_servico = @idPecaServico
		commit
		print 'Peça removida do serviço com sucesso'
	end try
	begin catch
		if @@TRANCOUNT > 0
			rollback;
		throw;
	end catch
end
go
