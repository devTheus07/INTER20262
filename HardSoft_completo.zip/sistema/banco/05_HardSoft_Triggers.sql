﻿------------------------------------------------------------------
-- FACULDADE DE TECNOLOGIA DE SÃO JOSÉ DO RIO PRETO - FATEC
-- PROJETO: HARDSOFT - SISTEMA DE ORDEM DE SERVIÇO
------------------------------------------------------------------
--	SCRIPT 05: TRIGGERS
--	Regras que o banco executa sozinho, sempre que os dados mudam
--	(baixa de estoque, valor total da OS, logs, etc.)
------------------------------------------------------------------

------------------------------------------------------------------
-- ACESSAR O BANCO DE DADOS
------------------------------------------------------------------
use HardSoftDB
go

------------------------------------------------------------------
-- 1) Criar um trigger que sempre que o preço de venda das peças
-- for alterado, registre os dados da alteração na tabela de LOG
-- de histórico de preços
-- Tabela:		tb_pecas
-- Operação:	update
-- Tipo:		AFTER
------------------------------------------------------------------
create trigger tg_LogPrecoPeca
ON		tb_pecas
AFTER	update
as
begin
	set nocount on
	-- inserir os dados na tabela de LOG, mas somente se o preço foi alterado
	insert into LOG_HistoricoPrecoPeca (idPeca, data, precoAntigo, precoNovo, usuario)
		select	I.id_peca, GETDATE(), D.preco_venda, I.preco_venda, SYSTEM_USER
		from	inserted as I, deleted as D
		where	I.id_peca = D.id_peca				-- peça sofrendo update
		and		I.preco_venda != D.preco_venda		-- preço novo diferente do preço antigo
end
go

------------------------------------------------------------------
-- 2) Criar um trigger que registre na tabela de LOG os dados de
-- toda OS nova que for aberta
-- Tabela:		tb_ordens_servico
-- Operação:	insert
-- Tipo:		AFTER
------------------------------------------------------------------
create trigger tg_LogOSNova
ON		tb_ordens_servico
AFTER	insert
as
begin
	set nocount on
	insert into LOG_HistoricoOS (idOS, data, idCliente, nomeCliente, nomeAdmin, usuario)
		select	I.id_ordem_servico, GETDATE(), I.id_cliente, vC.Cliente_Nome, vA.Admin_Nome, SYSTEM_USER
		from	inserted I						INNER JOIN		v_Cliente vC
		ON		I.id_cliente = vC.Cod_Cliente	INNER JOIN		v_Admin vA
		ON		I.id_admin = vA.Cod_Admin
end
go

------------------------------------------------------------------
-- 3) Criar um trigger que não permita a exclusão física de um
-- cliente. Sempre que se tentar excluir um cliente, deve-se
-- inativá-lo (status_cliente = 'INATIVO')
-- Tabela:		tb_clientes
-- Operação:	delete
-- Tipo:		INSTEAD OF - no lugar do delete será feito update
------------------------------------------------------------------
create trigger tg_ExcluiCliente
ON			tb_clientes
INSTEAD OF	delete
as
begin
	set nocount on
	-- não faremos delete, faremos update
	update tb_clientes set status_cliente = 'INATIVO'
	where id in	(
					select id
					from deleted
				)
end
go

------------------------------------------------------------------
-- 4) Criar um trigger que garanta que cada cliente tenha um único
-- e-mail principal
-- - se o e-mail novo for o principal, os outros deixam de ser
-- - se o cliente ficou sem e-mail principal, o novo vira o principal
-- Tabela:		tb_cliente_emails
-- Operação:	insert
-- Tipo:		AFTER
------------------------------------------------------------------
create trigger tg_EmailPrincipal
ON		tb_cliente_emails
AFTER	insert
as
begin
	set nocount on
	-- desmarcar o principal antigo
	update tb_cliente_emails set principal = 0
	where	principal = 1
	and		id_cliente in	(select id_cliente from inserted where principal = 1)
	and		id_email not in	(select id_email from inserted where principal = 1)

	-- se o cliente não tiver nenhum e-mail principal, o novo vira o principal
	update tb_cliente_emails set principal = 1
	where id_email in	(
							select	I.id_email
							from	inserted I
							where	(
										select	count(*)
										from	tb_cliente_emails E
										where	E.id_cliente = I.id_cliente and E.principal = 1
									) = 0
						)
end
go

------------------------------------------------------------------
-- 5) Criar um trigger que garanta que cada cliente tenha um único
-- telefone principal (mesma regra do trigger anterior)
-- Tabela:		tb_cliente_telefones
-- Operação:	insert
-- Tipo:		AFTER
------------------------------------------------------------------
create trigger tg_TelefonePrincipal
ON		tb_cliente_telefones
AFTER	insert
as
begin
	set nocount on
	-- desmarcar o principal antigo
	update tb_cliente_telefones set principal = 0
	where	principal = 1
	and		id_cliente in		(select id_cliente from inserted where principal = 1)
	and		id_telefone not in	(select id_telefone from inserted where principal = 1)

	-- se o cliente não tiver nenhum telefone principal, o novo vira o principal
	update tb_cliente_telefones set principal = 1
	where id_telefone in	(
								select	I.id_telefone
								from	inserted I
								where	(
											select	count(*)
											from	tb_cliente_telefones T
											where	T.id_cliente = I.id_cliente and T.principal = 1
										) = 0
							)
end
go

------------------------------------------------------------------
-- 6) Criar um trigger que dê baixa no estoque sempre que uma
-- peça for usada em um serviço
-- Tabela:		tb_pecas_servicos
-- Operação:	insert
-- Tipo:		AFTER
------------------------------------------------------------------
create trigger tg_BaixaEstoque
ON		tb_pecas_servicos
AFTER	insert
as
begin
	set nocount on
	-- update na qtd em estoque subtraindo a qtd usada
	update tb_pecas set qnt_estoque = qnt_estoque -	(
														select	sum(I.qnt_vendida)
														from	inserted I
														where	I.id_peca = tb_pecas.id_peca
													)
	where id_peca in	(
							select id_peca
							from inserted
						)
end
go

------------------------------------------------------------------
-- 7) Criar um trigger que devolva a peça ao estoque sempre que
-- ela for removida de um serviço
-- Tabela:		tb_pecas_servicos
-- Operação:	delete
-- Tipo:		AFTER
------------------------------------------------------------------
create trigger tg_DevolveEstoque
ON		tb_pecas_servicos
AFTER	delete
as
begin
	set nocount on
	-- update na qtd em estoque somando a qtd devolvida
	update tb_pecas set qnt_estoque = qnt_estoque +	(
														select	sum(D.qnt_vendida)
														from	deleted D
														where	D.id_peca = tb_pecas.id_peca
													)
	where id_peca in	(
							select id_peca
							from deleted
						)
end
go

------------------------------------------------------------------
-- 8) Criar um trigger para calcular o valor total da OS sempre
-- que um serviço for adicionado, alterado ou excluído
-- Tabela:		tb_servicos_executados
-- Operação:	insert, update e delete
-- Tipo:		AFTER
-- Objetivo:	usar a função fc_CalcTotalOS
------------------------------------------------------------------
create trigger tg_CalcTotalOS_Servico
ON		tb_servicos_executados
AFTER	insert, update, delete
as
begin
	set nocount on
	update tb_ordens_servico set valor_total = dbo.fc_CalcTotalOS(id_ordem_servico)
	where id_ordem_servico in	(
									select id_ordem_servico from inserted
									union
									select id_ordem_servico from deleted
								)
end
go

------------------------------------------------------------------
-- 9) Criar um trigger para calcular o valor total da OS sempre
-- que uma peça for usada ou removida de um serviço
-- Tabela:		tb_pecas_servicos
-- Operação:	insert e delete
-- Tipo:		AFTER
------------------------------------------------------------------
create trigger tg_CalcTotalOS_Peca
ON		tb_pecas_servicos
AFTER	insert, delete
as
begin
	set nocount on
	update tb_ordens_servico set valor_total = dbo.fc_CalcTotalOS(id_ordem_servico)
	where id_ordem_servico in	(
									select	S.id_ordem_servico
									from	tb_servicos_executados S
									where	S.id_servico in	(
																select id_servico from inserted
																union
																select id_servico from deleted
															)
								)
end
go

------------------------------------------------------------------
-- 10) Criar um trigger que controle a mudança de status da OS
-- - OS concluída, entregue ou cancelada não pode mudar de status
-- - ao concluir, entregar ou cancelar, preenche a data de saída
-- - ao cancelar, as peças usadas voltam para o estoque
-- Tabela:		tb_ordens_servico
-- Operação:	update
-- Tipo:		AFTER
-- Objetivo:	usar as tabelas inserted e deleted junto com tabelas físicas
------------------------------------------------------------------
create trigger tg_StatusOS
ON		tb_ordens_servico
AFTER	update
as
begin
	set nocount on
	-- bloquear a mudança de status de OS finalizada
	if exists	(
					select	I.id_ordem_servico
					from	inserted I, deleted D
					where	I.id_ordem_servico = D.id_ordem_servico
					and		D.status in ('CONCLUIDA', 'ENTREGUE', 'CANCELADA')
					and		I.status != D.status
				)
		throw 50002, 'Esta Ordem de Serviço já foi finalizada e não pode mais ter o status alterado.', 1;

	-- preencher a data de saída das OS que foram finalizadas
	update tb_ordens_servico set data_saida = GETDATE()
	where	data_saida is null
	and		id_ordem_servico in	(
									select	I.id_ordem_servico
									from	inserted I, deleted D
									where	I.id_ordem_servico = D.id_ordem_servico
									and		I.status != D.status
									and		I.status in ('CONCLUIDA', 'ENTREGUE', 'CANCELADA')
								)

	-- OS cancelada: excluir as peças usadas (o trigger tg_DevolveEstoque devolve ao estoque)
	delete from tb_pecas_servicos
	where id_servico in	(
							select	S.id_servico
							from	tb_servicos_executados S
							where	S.id_ordem_servico in	(
																select	I.id_ordem_servico
																from	inserted I, deleted D
																where	I.id_ordem_servico = D.id_ordem_servico
																and		I.status = 'CANCELADA'
																and		D.status != 'CANCELADA'
															)
						)
end
go
