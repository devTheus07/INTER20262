﻿------------------------------------------------------------------
-- FACULDADE DE TECNOLOGIA DE SÃO JOSÉ DO RIO PRETO - FATEC
-- PROJETO: HARDSOFT - SISTEMA DE ORDEM DE SERVIÇO
------------------------------------------------------------------
--	SCRIPT 06: DADOS DE TESTE
--	Os dados são cadastrados usando as procedures, do mesmo jeito
--	que o sistema faz. Execute uma única vez, logo após os
--	scripts 01 a 05.
--
--	Logins para testar o sistema:
--		matheus@hardsoft.com / senha123
--		ana@hardsoft.com     / senha456
------------------------------------------------------------------

------------------------------------------------------------------
-- ACESSAR O BANCO DE DADOS
------------------------------------------------------------------
use HardSoftDB
go

------------------------------------------------------------------
-- Cadastrar 10 administradores (ids 1 a 10)
-- nome, e-mail, senha, cargo, telefone, endereço
------------------------------------------------------------------
exec sp_CadAdmin 'Matheus Técnico', 'matheus@hardsoft.com',  'senha123', 'Técnico',   '17999990001', 'Rua da Oficina, 50'
exec sp_CadAdmin 'Ana Gerente',     'ana@hardsoft.com',      'senha456', 'Gerente',   '17999990002', 'Rua da Oficina, 50'
exec sp_CadAdmin 'Leandro Belati',  'leandro@hardsoft.com',  'senha789', 'Técnico',   '17999990003', 'Rua da Oficina, 50'
exec sp_CadAdmin 'Davi Vieira',     'davi@hardsoft.com',     'senha101', 'Técnico',   '17999990004', 'Rua da Oficina, 50'
exec sp_CadAdmin 'Carlos Pereira',  'carlos@hardsoft.com',   'senha112', 'Atendente', '17999990005', 'Rua da Oficina, 50'
exec sp_CadAdmin 'Fernanda Lima',   'fernanda@hardsoft.com', 'senha131', 'Técnico',   '17999990006', 'Rua da Oficina, 50'
exec sp_CadAdmin 'Roberto Alves',   'roberto@hardsoft.com',  'senha415', 'Atendente', '17999990007', 'Rua da Oficina, 50'
exec sp_CadAdmin 'Juliana Castro',  'juliana@hardsoft.com',  'senha161', 'Técnico',   '17999990008', 'Rua da Oficina, 50'
exec sp_CadAdmin 'Paulo Mendes',    'paulo@hardsoft.com',    'senha718', 'Gerente',   '17999990009', 'Rua da Oficina, 50'
exec sp_CadAdmin 'Beatriz Rocha',   'beatriz@hardsoft.com',  'senha192', 'Técnico',   '17999990010', 'Rua da Oficina, 50'
go

select * from v_Admin
go

------------------------------------------------------------------
-- Cadastrar 12 clientes (ids 11 a 22)
-- nome, CPF/CNPJ, RG, endereço
------------------------------------------------------------------
exec sp_CadCliente 'João da Silva',       '11111111111',    'SP100001', 'Rua A, 100'
exec sp_CadCliente 'Maria Oliveira',      '22222222222',    'SP100002', 'Rua B, 200'
exec sp_CadCliente 'Tech Solutions LTDA', '33333333000199', null,       'Av. Comercial, 1500'
exec sp_CadCliente 'Pedro Santos',        '44444444444',    'SP100004', 'Rua C, 300'
exec sp_CadCliente 'Carla Ferreira',      '55555555555',    'SP100005', 'Rua D, 400'
exec sp_CadCliente 'Lucas Martins',       '66666666666',    'SP100006', 'Rua E, 500'
exec sp_CadCliente 'Amanda Costa',        '77777777777',    'SP100007', 'Rua F, 600'
exec sp_CadCliente 'InfoShop ME',         '88888888000188', null,       'Av. Brasil, 2000'
exec sp_CadCliente 'Rafael Gomes',        '99999999999',    'SP100009', 'Rua G, 700'
exec sp_CadCliente 'Patrícia Dias',       '10101010101',    'SP100010', 'Rua H, 800'
exec sp_CadCliente 'Bruno Azevedo',       '12121212121',    'SP100011', 'Rua I, 900'
exec sp_CadCliente 'Escola Saber LTDA',   '13131313000177', null,       'Av. Educação, 350'
go

------------------------------------------------------------------
-- Cadastrar os e-mails dos clientes
-- id do cliente, e-mail, principal (1 - sim | 0 - não)
------------------------------------------------------------------
exec sp_CadEmailCliente 11, 'joao@email.com',               1
exec sp_CadEmailCliente 11, 'joao.silva@trabalho.com',      0
exec sp_CadEmailCliente 12, 'maria@email.com',              1
exec sp_CadEmailCliente 13, 'contato@techsolutions.com',    1
exec sp_CadEmailCliente 13, 'financeiro@techsolutions.com', 0
exec sp_CadEmailCliente 14, 'pedro@email.com',              1
exec sp_CadEmailCliente 15, 'carla@email.com',              1
exec sp_CadEmailCliente 16, 'lucas@email.com',              1
exec sp_CadEmailCliente 17, 'amanda@email.com',             1
exec sp_CadEmailCliente 18, 'vendas@infoshop.com',          1
exec sp_CadEmailCliente 19, 'rafael@email.com',             1
exec sp_CadEmailCliente 20, 'patricia@email.com',           1
exec sp_CadEmailCliente 21, 'bruno@email.com',              1
exec sp_CadEmailCliente 22, 'contato@escolasaber.com',      1
go

------------------------------------------------------------------
-- Cadastrar os telefones dos clientes
-- id do cliente, telefone, tipo, principal (1 - sim | 0 - não)
------------------------------------------------------------------
exec sp_CadTelefoneCliente 11, '17988880001', 'CELULAR',   1
exec sp_CadTelefoneCliente 11, '1733330011',  'FIXO',      0
exec sp_CadTelefoneCliente 12, '17988880002', 'CELULAR',   1
exec sp_CadTelefoneCliente 13, '1733330003',  'COMERCIAL', 1
exec sp_CadTelefoneCliente 13, '17988880013', 'CELULAR',   0
exec sp_CadTelefoneCliente 14, '17988880004', 'CELULAR',   1
exec sp_CadTelefoneCliente 15, '17988880005', 'CELULAR',   1
exec sp_CadTelefoneCliente 16, '17988880006', 'CELULAR',   1
exec sp_CadTelefoneCliente 17, '17988880007', 'CELULAR',   1
exec sp_CadTelefoneCliente 18, '1733330008',  'COMERCIAL', 1
exec sp_CadTelefoneCliente 19, '17988880009', 'CELULAR',   1
exec sp_CadTelefoneCliente 20, '1733330010',  'FIXO',      1
exec sp_CadTelefoneCliente 21, '17988880011', 'CELULAR',   1
exec sp_CadTelefoneCliente 22, '1733330012',  'COMERCIAL', 1
go

select * from v_Cliente
go

select * from v_ClienteContatos
go

------------------------------------------------------------------
-- Cadastrar 12 setups, um para cada cliente (ids 1 a 12)
-- id do cliente, marca, modelo, processador, memória,
-- placa de vídeo, armazenamento
------------------------------------------------------------------
exec sp_CadSetup 11, 'Dell',     'Inspiron 15', 'Intel i5',      '8GB DDR4',  'Integrada', 'SSD 256GB'
exec sp_CadSetup 12, 'Apple',    'MacBook Air', 'Apple M1',      '8GB',       'Integrada', 'SSD 256GB'
exec sp_CadSetup 13, 'HP',       'ProDesk 400', 'Intel i7',      '16GB DDR4', 'Integrada', 'SSD 512GB'
exec sp_CadSetup 14, 'Acer',     'Aspire 5',    'Ryzen 5',       '8GB DDR4',  'Integrada', 'HD 1TB'
exec sp_CadSetup 15, 'Lenovo',   'IdeaPad 3',   'Intel i3',      '4GB DDR4',  'Integrada', 'HD 500GB'
exec sp_CadSetup 16, 'Asus',     'VivoBook',    'Ryzen 7',       '16GB DDR4', 'GTX 1650',  'SSD 512GB'
exec sp_CadSetup 17, 'Dell',     'XPS 13',      'Intel i7',      '16GB DDR4', 'Integrada', 'SSD 1TB'
exec sp_CadSetup 18, 'HP',       'EliteBook',   'Intel i5',      '8GB DDR4',  'Integrada', 'SSD 256GB'
exec sp_CadSetup 19, 'Samsung',  'Book',        'Intel i5',      '8GB DDR4',  'Integrada', 'SSD 256GB'
exec sp_CadSetup 20, 'Positivo', 'Motion',      'Intel Celeron', '4GB DDR4',  'Integrada', 'HD 500GB'
exec sp_CadSetup 21, 'Acer',     'Nitro 5',     'Intel i7',      '16GB DDR4', 'RTX 3050',  'SSD 512GB'
exec sp_CadSetup 22, 'Dell',     'OptiPlex',    'Intel i5',      '8GB DDR4',  'Integrada', 'SSD 256GB'
go

select * from v_Setup
go

------------------------------------------------------------------
-- Cadastrar 12 peças (ids 1 a 12)
-- nome, descrição, marca, condição, preço de custo,
-- preço de venda, quantidade em estoque
------------------------------------------------------------------
exec sp_CadPeca 'SSD 480GB',               'SSD SATA 2.5',      'Kingston',      'NOVO', 180.00,  280.00, 30
exec sp_CadPeca 'Memória 8GB DDR4',        'RAM 2666MHz',       'Corsair',       'NOVO', 120.00,  200.00, 25
exec sp_CadPeca 'Fonte 500W',              'Fonte ATX 80 Plus', 'Corsair',       'NOVO', 200.00,  320.00, 15
exec sp_CadPeca 'HD 1TB',                  'HD 7200rpm',        'Seagate',       'NOVO', 180.00,  260.00, 20
exec sp_CadPeca 'Cooler CPU',              'Air Cooler',        'Cooler Master', 'NOVO',  90.00,  150.00, 18
exec sp_CadPeca 'Pasta Térmica',           'Seringa 4g',        'Arctic',        'NOVO',  20.00,   40.00, 50
exec sp_CadPeca 'Teclado USB',             'Teclado ABNT2',     'Logitech',      'NOVO',  45.00,   80.00, 40
exec sp_CadPeca 'Mouse USB',               'Mouse óptico',      'Logitech',      'NOVO',  30.00,   60.00, 45
exec sp_CadPeca 'Placa de Vídeo GTX 1650', 'GPU 4GB',           'MSI',           'NOVO', 900.00, 1300.00,  8
exec sp_CadPeca 'Bateria Notebook',        'Bateria 6 células', 'Genérica',      'NOVO', 150.00,  250.00, 12
exec sp_CadPeca 'Tela 15.6',               'LCD Full HD',       'AUO',           'NOVO', 300.00,  480.00, 10
exec sp_CadPeca 'Cabo SATA',               'Cabo de dados',     'Genérica',      'NOVO',   8.00,   18.00, 60
go

select * from v_PecaEstoque
go

------------------------------------------------------------------
-- Cadastrar 10 tipos de serviço (ids 1 a 10)
-- nome, descrição, valor base
------------------------------------------------------------------
exec sp_CadTipoServico 'Formatação',              'Formatação e reinstalação do sistema',    120.00
exec sp_CadTipoServico 'Limpeza Interna',         'Limpeza física e troca de pasta térmica',  80.00
exec sp_CadTipoServico 'Troca de Peça',           'Substituição de componente de hardware',   60.00
exec sp_CadTipoServico 'Remoção de Vírus',        'Remoção de malware e otimização',         100.00
exec sp_CadTipoServico 'Upgrade de Hardware',     'Instalação de novos componentes',          90.00
exec sp_CadTipoServico 'Backup de Dados',         'Cópia de segurança dos arquivos',          70.00
exec sp_CadTipoServico 'Instalação de Programas', 'Instalação de softwares diversos',         50.00
exec sp_CadTipoServico 'Diagnóstico',             'Análise técnica do equipamento',           40.00
exec sp_CadTipoServico 'Reparo de Placa',         'Reparo em placa-mãe e circuitos',         250.00
exec sp_CadTipoServico 'Recuperação de Dados',    'Recuperação de arquivos perdidos',        300.00
go

select * from v_TipoServico
go

------------------------------------------------------------------
-- Abrir 12 ordens de serviço (ids 1 a 12)
-- id do cliente, id do setup, id do administrador, defeito,
-- solução, status (null = ABERTA)
------------------------------------------------------------------
exec sp_AbrirOS 11, 1,  2, 'PC não liga',          null, null
exec sp_AbrirOS 12, 2,  2, 'Lentidão',             null, null
exec sp_AbrirOS 13, 3,  3, 'Tela quebrada',        null, null
exec sp_AbrirOS 14, 4,  4, 'Não dá vídeo',         null, null
exec sp_AbrirOS 15, 5,  2, 'Sem som',              null, null
exec sp_AbrirOS 16, 6,  6, 'Vírus',                null, null
exec sp_AbrirOS 17, 7,  4, 'Upgrade de memória',   null, null
exec sp_AbrirOS 18, 8,  2, 'Superaquecimento',     null, null
exec sp_AbrirOS 19, 9,  6, 'Backup dos arquivos',  null, null
exec sp_AbrirOS 20, 10, 5, 'Orçamento alto',       null, null
exec sp_AbrirOS 21, 11, 3, 'HD com defeito',       null, null
exec sp_AbrirOS 22, 12, 4, 'Não conecta no Wi-Fi', null, null
go

select * from LOG_HistoricoOS
go

------------------------------------------------------------------
-- Adicionar 12 serviços nas OS (ids 1 a 12)
-- id da OS, id do tipo de serviço, descrição, mão de obra
-- (o trigger tg_CalcTotalOS_Servico calcula o valor total da OS)
------------------------------------------------------------------
exec sp_AddServicoOS 2,  1, 'Formatação completa',        120.00
exec sp_AddServicoOS 2,  3, 'Instalação de SSD',           60.00
exec sp_AddServicoOS 3,  3, 'Troca da tela LCD',           60.00
exec sp_AddServicoOS 6,  4, 'Remoção de malwares',        100.00
exec sp_AddServicoOS 7,  5, 'Instalação de pente de RAM',  90.00
exec sp_AddServicoOS 9,  6, 'Backup dos documentos',       70.00
exec sp_AddServicoOS 11, 3, 'Troca do HD por um novo',     60.00
exec sp_AddServicoOS 2,  2, 'Limpeza interna completa',    80.00
exec sp_AddServicoOS 3,  8, 'Diagnóstico inicial',         40.00
exec sp_AddServicoOS 7,  7, 'Instalação de programas',     50.00
exec sp_AddServicoOS 6,  8, 'Otimização do sistema',       40.00
exec sp_AddServicoOS 11, 3, 'Configuração após a troca',   60.00
go

------------------------------------------------------------------
-- Usar 12 peças nos serviços
-- id do serviço, id da peça, quantidade
-- (o trigger tg_BaixaEstoque dá baixa no estoque e o trigger
-- tg_CalcTotalOS_Peca recalcula o valor total da OS)
------------------------------------------------------------------
exec sp_UsarPecaServico 2,  1,  1	-- SSD na instalação de SSD
exec sp_UsarPecaServico 3,  11, 1	-- tela na troca de tela
exec sp_UsarPecaServico 5,  2,  1	-- memória no upgrade
exec sp_UsarPecaServico 7,  4,  1	-- HD novo
exec sp_UsarPecaServico 8,  6,  1	-- pasta térmica na limpeza
exec sp_UsarPecaServico 2,  12, 2	-- cabos SATA
exec sp_UsarPecaServico 5,  5,  1	-- cooler
exec sp_UsarPecaServico 10, 7,  1	-- teclado
exec sp_UsarPecaServico 10, 8,  1	-- mouse
exec sp_UsarPecaServico 1,  3,  1	-- fonte
exec sp_UsarPecaServico 4,  10, 1	-- bateria
exec sp_UsarPecaServico 12, 12, 1	-- cabo SATA
go

select * from v_ServicoExecutado
go

select * from v_PecaServico
go

------------------------------------------------------------------
-- Andamento das OS
-- id da OS, novo status
------------------------------------------------------------------
exec sp_AlterarStatusOS 2,  'CONCLUIDA'
exec sp_AlterarStatusOS 6,  'CONCLUIDA'
exec sp_AlterarStatusOS 9,  'CONCLUIDA'
exec sp_AlterarStatusOS 3,  'ENTREGUE'
exec sp_AlterarStatusOS 7,  'ENTREGUE'
exec sp_AlterarStatusOS 11, 'ENTREGUE'
exec sp_AlterarStatusOS 4,  'EM_ANDAMENTO'
exec sp_AlterarStatusOS 12, 'EM_ANDAMENTO'
exec sp_AlterarStatusOS 5,  'AGUARDANDO_PECA'
-- OS 10 cancelada: o trigger tg_StatusOS devolve as peças ao estoque
exec sp_AlterarStatusOS 10, 'CANCELADA'
go

select * from v_OS
go

------------------------------------------------------------------
-- Alterar o preço de uma peça para testar o LOG de preços
-- (aumento de 10% na peça 1 usando a função fc_CalcReajuste)
------------------------------------------------------------------
update	tb_pecas set preco_venda = dbo.fc_CalcReajuste(preco_venda, 10)
where	id_peca = 1
go

select * from LOG_HistoricoPrecoPeca
go

------------------------------------------------------------------
-- Testar as functions
------------------------------------------------------------------
-- valor total da OS 2
select dbo.fc_CalcTotalOS(2) Total_OS
go

-- quantidade já usada da peça 12
select dbo.fc_QtdVendidaPeca(12) Qtd_Vendida
go

-- peças com menos de 15 unidades em estoque
select * from dbo.fc_PecasEstoqueMinimo(15)
go

-- OS abertas no mês atual
select * from dbo.fc_OSsPorMes(MONTH(GETDATE()), YEAR(GETDATE()))
go

-- peças com preço de venda acima de 200,00
select * from dbo.fc_PecasPreco(200.00)
go

-- histórico de OS do cliente 11
select * from dbo.fc_OSsPorCliente(11)
go

-- faturamento por administrador
select * from v_FaturamentoAdmin
go
